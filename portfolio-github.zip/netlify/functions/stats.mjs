// Returns the visitor summary to the Studio dashboard. Needs the x-admin-token header.
import { getStore } from "@netlify/blobs";
import { json, requireAdmin } from "../lib/auth.mjs";

export default async (req) => {
  const denied = requireAdmin(req);
  if (denied) return denied;
  const s = (await getStore("portfolio-visits").get("summary", { type: "json" })) || {};
  return json({
    total: s.total || 0,
    since: s.since || null,
    days: s.days || {},
    countries: Object.entries(s.countries || {}).map(([code, v]) => ({ code, name: v.name, count: v.count })).sort((a, b) => b.count - a.count),
    cities: Object.values(s.cities || {}).sort((a, b) => b.count - a.count).slice(0, 200),
    recent: s.recent || [],
  });
};
