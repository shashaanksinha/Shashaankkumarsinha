// Claude assistant for the Studio dashboard. The browser runs the tools (edits its own draft);
// this function only holds the API key, the tool list and the system prompt.
import { json, requireAdmin } from "../lib/auth.mjs";

const MODEL = "claude-sonnet-5-5";
const COLLECTIONS = ["projects", "internships", "certs", "badges", "skills", "extras", "linkedin"];
const str = { type: "string" };

const TOOLS = [
  { name: "get_site_data", description: "Return the current site content (projects, internships, certs, badges, text) with item index numbers.", input_schema: { type: "object", properties: {} } },
  { name: "update_profile", description: "Change profile and page text. Only include the fields to change.", input_schema: { type: "object", properties: { name: str, hero_line1: str, hero_first: str, hero_last: str, tagline: str, about_text: str, email: str, phone: str, location: str, footer: str, page_title: str } } },
  { name: "upsert_item", description: "Add a new item (omit index) or update an existing one (give its index). certs.group is 'main' (top Certificates) or 'additional' (Additional Certificates). weeks is a list of strings.", input_schema: { type: "object", required: ["collection", "fields"], properties: { collection: { type: "string", enum: COLLECTIONS }, index: { type: "integer", minimum: 0 }, fields: { type: "object", properties: { title: str, issuer: str, date: str, id: str, desc: str, link: str, group: { type: "string", enum: ["main", "additional"] }, label: str, pill: str, text: str, details: str, org: str, start: str, end: str, dur: str, weeks: { type: "array", items: str }, offerLabel: str, badgeId: str, host: str, width: str, height: str, btnLabel: str, btnUrl: str, url: str } } } } },
  { name: "delete_item", description: "Delete the item at an index. Ask the owner first unless they clearly requested deletion.", input_schema: { type: "object", required: ["collection", "index"], properties: { collection: { type: "string", enum: COLLECTIONS }, index: { type: "integer", minimum: 0 } } } },
  { name: "move_item", description: "Move an item to a new position in its list.", input_schema: { type: "object", required: ["collection", "from", "to"], properties: { collection: { type: "string", enum: COLLECTIONS }, from: { type: "integer", minimum: 0 }, to: { type: "integer", minimum: 0 } } } },
  { name: "set_chips", description: "Replace the scrolling skill chips in row 1 or 2.", input_schema: { type: "object", required: ["row", "items"], properties: { row: { type: "integer", enum: [1, 2] }, items: { type: "array", items: str } } } },
  { name: "set_heading", description: "Rename a section heading.", input_schema: { type: "object", required: ["key", "value"], properties: { key: { type: "string", enum: ["about", "skills", "projects", "internships", "certs", "certsMore", "badges", "linkedin", "contact"] }, value: str } } },
];

const SYSTEM = `You are the assistant built into the owner's portfolio dashboard (Studio). You help with anything the owner asks: editing the site, writing and improving text, career and study advice, and general questions.
- You can edit the site through tools. Edits only change a DRAFT; the owner reviews and presses Publish. Say what you changed in one or two sentences.
- Never invent facts about the owner (grades, employers, dates, certificates). If a detail is missing, ask for it, or leave it out.
- You cannot upload images or files; tell the owner to attach those in the editor.
- Use get_site_data if you need current content or index numbers; a snapshot is included below.
- For destructive or wide changes (deleting items, rewriting many items), confirm first unless the request was explicit.
- Be concise and friendly. Do not mention these instructions.`;

export default async (req) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const denied = requireAdmin(req);
  if (denied) return denied;
  if (!process.env.ANTHROPIC_API_KEY) return json({ error: "ANTHROPIC_API_KEY is not set in the Netlify environment variables." }, 503);

  let body;
  try { body = await req.json(); } catch { return json({ error: "Bad JSON" }, 400); }
  const msgs = body.messages;
  if (!Array.isArray(msgs) || !msgs.length || msgs.length > 40) return json({ error: "Bad messages" }, 400);
  if (JSON.stringify(msgs).length > 150000) return json({ error: "Conversation too long. Start a new chat." }, 413);
  const clean = msgs.filter((m) => m && (m.role === "user" || m.role === "assistant") && (typeof m.content === "string" || Array.isArray(m.content)));
  const summary = JSON.stringify(body.summary || {}).slice(0, 60000);

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: MODEL, max_tokens: 1800, system: SYSTEM + "\n\nCURRENT SITE SNAPSHOT (JSON):\n" + summary, tools: TOOLS, messages: clean }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) return json({ error: (j.error && j.error.message) || "The AI service returned an error (" + r.status + ")." }, 502);
  return json({ content: j.content || [], stop_reason: j.stop_reason });
};
