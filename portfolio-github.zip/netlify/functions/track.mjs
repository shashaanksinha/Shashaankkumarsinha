// Counts one visit (country + city only, never the IP address). Called once per browser session by js/site.js.
import { getStore } from "@netlify/blobs";

const BOT = /bot|crawl|spider|slurp|preview|headless|lighthouse|facebookexternalhit|monitor|curl|wget|python-requests/i;
const r1 = (n) => (typeof n === "number" ? Math.round(n * 10) / 10 : null);

export default async (req, context) => {
  if (req.method !== "POST") return new Response(null, { status: 204 });
  if (BOT.test(req.headers.get("user-agent") || "")) return new Response(null, { status: 204 });
  let body = {};
  try { body = await req.json(); } catch {}
  const g = (context && context.geo) || {};
  const cc = (g.country && g.country.code) || "";
  const country = (g.country && g.country.name) || "";
  const city = g.city || "";

  const store = getStore("portfolio-visits");
  const s = (await store.get("summary", { type: "json" })) || {};
  s.total = (s.total || 0) + 1;
  s.since = s.since || Date.now();
  s.days = s.days || {}; s.countries = s.countries || {}; s.cities = s.cities || {}; s.recent = s.recent || [];

  const day = new Date().toISOString().slice(0, 10);
  s.days[day] = (s.days[day] || 0) + 1;
  Object.keys(s.days).sort().slice(0, Math.max(0, Object.keys(s.days).length - 90)).forEach((k) => delete s.days[k]);

  const ck = cc || "??";
  s.countries[ck] = { name: country || s.countries[ck]?.name || "Unknown", count: (s.countries[ck]?.count || 0) + 1 };
  if (city || cc) {
    const key = cc + "|" + city;
    const prev = s.cities[key] || { city, country, cc, lat: r1(g.latitude), lon: r1(g.longitude), count: 0 };
    prev.count += 1;
    s.cities[key] = prev;
    const keys = Object.keys(s.cities);
    if (keys.length > 300) keys.sort((a, b) => s.cities[a].count - s.cities[b].count).slice(0, keys.length - 300).forEach((k) => delete s.cities[k]);
  }
  s.recent.unshift({ t: Date.now(), cc, city, ref: String(body.r || "").slice(0, 60) });
  s.recent = s.recent.slice(0, 50);

  await store.setJSON("summary", s);
  return new Response(null, { status: 204 });
};
