/* Visitor chat box: built-in answers from the site data, optionally upgraded to Claude by a Netlify function */
  /* ---------- Chat engine ---------- */
  const USE_AI_FUNCTION=true; // tries the Netlify function first (real AI); silently falls back to the built-in engine below if it isn't deployed
  let KB=[],FACTS=[],COUNTS={},CERTS=[];
  let EMAIL='',PHONE='';
  const STOP=new Set(("a an the is are was were be been am do does did have has had having doesn't don't didn't isn't aren't wasn't weren't hasn't haven't hadn't can't couldn't won't wouldn't shouldn't i you your yours he his him she her they their it its of in on at to for from with about and or but what which who whom how when where why can could would should will shall may might tell me us any some also please shashaank kumar sinha s there that this these those so than then if whether person guy man boy someone people kind type really just very much many get gets got").split(' '));
  const GENERIC=new Set('know knowledge experience skill familiar proficient good great able ever certified certificate certification credential course learn learned use used work worked built make made complete completed hold earn earned currently still already yet actually ability expert expertise pro professional have ok okay done participate participated take took attend attended join joined involved help want need study fluent speak pursuing pursue'.split(' '));
  const SYN={uni:'university',univ:'university',college:'university',cert:'certificate',mail:'email',gmail:'email',mobile:'phone',cell:'phone',whatsapp:'phone',call:'phone',job:'internship',intern:'internship',studied:'study',studying:'study',studies:'study',ppt:'powerpoint',genai:'generative',tab:'tableau',db:'database',gen:'generative'};
  function stem(w){w=w.replace(/'s$/,'');if(w.length>4&&/ies$/.test(w))w=w.slice(0,-3)+'y';else if(w.length>3&&/s$/.test(w)&&!/ss$/.test(w))w=w.slice(0,-1);return SYN[w]||w;}
  const pairs=s=>(s.toLowerCase().match(/[a-z0-9']+/g)||[]).map(o=>({o,w:stem(o)})).filter(p=>p.w&&!STOP.has(p.w)&&!STOP.has(p.o));
  const tok=s=>pairs(s).map(p=>p.w);
  let FT=[];
  let KBT=[];
  let VOCAB=new Set();
  let DF={};
  const GENC=new Set(['certificate','certification','certified','credential','course','job','simulation','programme','internship']);
  const GENY=new Set(['certificate','certification','certified','credential','programme']);
  let CT=[];
  let DFC={};
  function rebuildIndex(){
    FT=FACTS.map(f=>({f,t:new Set(tok(f.k))}));
    KBT=KB.map(e=>({e,t:new Set(tok(e.k))}));
    VOCAB=new Set();FT.forEach(x=>x.t.forEach(w=>VOCAB.add(w)));KBT.forEach(x=>x.t.forEach(w=>VOCAB.add(w)));
    DF={};KBT.forEach(x=>x.t.forEach(w=>{DF[w]=(DF[w]||0)+1;}));
    CT=CERTS.map(c=>({c,t:new Set(tok(c.t+' '+c.i).filter(w=>!GENC.has(w)))}));
    DFC={};CT.forEach(x=>x.t.forEach(w=>{DFC[w]=(DFC[w]||0)+1;}));
  }
  function lev(a,b){const m=a.length,n=b.length;if(Math.abs(m-n)>2)return 9;let p=Array.from({length:n+1},(_,j)=>j);for(let i=1;i<=m;i++){const c=[i];for(let j=1;j<=n;j++)c[j]=Math.min(p[j]+1,c[j-1]+1,p[j-1]+(a[i-1]===b[j-1]?0:1));p=c;}return p[n];}
  function fix(w){if(w.length<5||VOCAB.has(w)||/\d/.test(w))return w;const lim=w.length>=8?2:1;let best=w,bd=lim+1;VOCAB.forEach(v=>{if(v.length<4)return;const d=lev(w,v);if(d<bd){bd=d;best=v;}});return best;}
  const analyse=q=>pairs(q).map(p=>({o:p.o,w:fix(p.w)}));

  const AUX=/^(is|are|was|were|am|do|does|did|has|have|had|can|could|will|would|should|shall|may|might|isn't|aren't|doesn't|don't|didn't|hasn't|haven't|wasn't|weren't|won't|can't|couldn't|wouldn't|shouldn't)\b/;
  const isYesNo=ql=>AUX.test(ql)||/^(is it true|tell me (if|whether)|can you tell me (if|whether)|i wonder (if|whether)|do you know (if|whether))/.test(ql)||/(,|\s)(right|correct|true|yes or no)\??$/.test(ql);
  const NEG=/\b(not|never)\b|n't\b/;

  let PRIVATE='',OUT='',UNKNOWN='',SCOPE='';

  /* small talk, checked first */
  const SMALL=[
    [/^(hi+|hello+|hey+|hiya|namaste|good (morning|afternoon|evening)|yo|sup)\b[\s!.?]*$/,()=>"Hi! Ask me anything about Shashaank, for example 'Does Shashaank know Excel?' or 'What internships has he done?'."],
    [/^(thanks|thank you|thx|ty|thanku|much appreciated|cheers)\b/,()=>"You're welcome! Anything else you'd like to know?"],
    [/^(bye|goodbye|see you|see ya|cya|take care)\b/,()=>"Thanks for stopping by! You can reach Shashaank at "+EMAIL+"."],
    [/^(ok|okay|cool|nice|great|awesome|got it|alright|fine|wow|perfect)[\s!.]*$/,()=>"Glad to help! Anything else you'd like to know?"],
    [/\bhow are you\b|\bhow('?s| is) it going\b|\bwhat'?s up\b/,()=>"Doing well, thanks for asking!"+SCOPE],
    [/\b(are|r) (you|u) (a |an )?(real|human|person|bot|robot|ai|chatbot|chat bot|machine|chatgpt|gpt|claude|gemini)\b|\bwho are you\b|\bwhat are you\b|\bis this (a )?(bot|ai|human)\b|\bwho (made|built|created|programmed|trained) you\b/,()=>"I'm an automated assistant on Shashaank's portfolio, not Shashaank himself."+SCOPE],
    [/\bwhat can you (do|help)\b|\bcan you (please )?(help|assist)\b|\bhow (do|can) i use (this|you)\b|^help\b|\bwhat should i ask\b|\bwhat (can|do) i ask\b/,()=>"Ask me about Shashaank's education, skills, projects (like the F1 Netflix Effect), internships, certificates or contact details. Yes/no questions work too, for example 'Does Shashaank have a Canva certificate?'."],
    [/\b(nice|great|awesome|good|cool|beautiful|amazing) (portfolio|site|website|work|page)\b/,()=>"Thank you! Anything about Shashaank's work you'd like to know more about?"],
    [/\b(fuck|shit|bitch|bastard|idiot|stupid|dumb)\b/,()=>"Let's keep it friendly."+SCOPE],
  ];
  /* explicit rules where keyword matching could mislead */
  const RULES=[
    [/\b(how old|his age|your age|shashaank'?s age|birthday|date of birth|\bdob\b|when (was|were) (he|you|shashaank) born|where (was|were) (he|you|shashaank) born|religio|\bcaste\b|politic|home address|residential address|street|salary|\bctc\b|stipend|income|expected pay|married|marital|wife|girlfriend|boyfriend|dating|is (he|shashaank) single|are you single|parents?\b|father|mother|sibling|brother|sister|family|aadhaar|aadhar|passport|\bpan card)/,()=>PRIVATE],
    [/\b(mba|mca|b\.?tech|m\.?tech|master'?s|phd|b\.?com|m\.?com|b\.?sc|engineering degree)\b/,()=>"No other degree is listed. Shashaank is a first-year BBA student at Amity University Online, expected to graduate in 2029."],
    [/\b(graduat|completed (his |the |your )?(degree|bba)|degree (holder|complete)|passed out|finish(ed)? (his |the |your )?(degree|bba))/,()=>"No, not yet. Shashaank is a first-year BBA student at Amity University Online, expected to graduate in 2029. 12th (Commerce, CBSE) was completed in 2026."],
    [/(full[- ]?time|employed|employment|currently working|has a job|have a job|(his|your) (current )?(job|employer|company)|where does (he|shashaank) work)/,()=>internSummary(false)],
    [/(work experience|professional experience|any experience|industry experience|has (he|shashaank) (worked|interned))/,()=>internSummary(true)],
    [/\b(hire|hiring|available|availability|open to (work|opportunit)|looking for (a )?(job|work|role|opportunit)|freelanc|relocat|notice period|recruit|collaborat|work with (him|you|shashaank))/,()=>"Availability and relocation aren't stated on the portfolio, so I can't say either way. The quickest way to find out is to email "+EMAIL+" or call "+PHONE+"."],
    [/\b(nationality|citizen|national of|is (he|shashaank) indian|are you indian)\b/,()=>"Nationality isn't stated on the portfolio. The CV lists schooling in the UAE and India, and a current base in Jamshedpur, Jharkhand, India."],
    [/\b(hard ?working|smart|intelligent|talented|honest|reliable|creative|passionate|dedicated|disciplined|trustworthy|genius|clever|good candidate)\b/,()=>"Character traits are subjective, so I won't vouch for them. What the CV does list: punctuality, adaptability, teamwork, public speaking and an entrepreneurial mindset, backed by two internships and "+COUNTS.certs+" certificates."],
    [/\b(email|e-mail|mail id|phone|contact (number|details|info)|how (can|do) i (contact|reach|call|email)|reach (him|you|shashaank))\b/,()=>"Contact: "+EMAIL+" or "+PHONE+". Based in Jamshedpur, Jharkhand, India."],
  ];

  function certList(tokens){
    const keys=tokens.filter(w=>!GENC.has(w)&&!GENERIC.has(w));
    let m=CERTS.map((c,i)=>({c,i,t:CT[i].t})).filter(x=>keys.some(w=>x.t.has(w)));
    const filtered=m.length>0&&m.length<CERTS.length; if(!filtered)m=CERTS.map((c,i)=>({c,i}));
    return (filtered?"Matching certificates ("+m.length+"):\n":"All "+CERTS.length+" certificates:\n")+m.map(x=>(x.i+1)+". "+x.c.t+(x.c.i?" - "+x.c.i:"")+(x.c.d?" ("+x.c.d+")":"")).join("\n")+"\nPress 'Show credentials' on a card to open it.";
  }
  const certAnswer=c=>`${c.t}${c.i?' from '+c.i:''}${c.d?' (issued '+c.d+')':''}${c.cid?', credential ID '+c.cid:''}. ${c.s||''} Find it as certificate #${c.n} under Certifications and press "Show credentials".`;

  function yesNo(ql,an){
    const neg=NEG.test(ql);
    const keys=an.filter(p=>!GENERIC.has(p.w)&&!GENY.has(p.w));
    if(!keys.length) return null;
    const ref=/\b(he|his|him|shashaank|sinha|you|your|yours)\b/.test(ql);
    const inScope=ref||keys.some(p=>VOCAB.has(p.w))||CT.some(x=>keys.some(p=>x.t.has(p.w)));
    if(!inScope) return OUT;
    const used=[];const matched=new Set();
    const wantCert=an.some(p=>GENY.has(p.w));
    let left=keys.slice();
    while(left.length){
      let best=null,bs=0;
      FT.forEach(x=>{let c=left.filter(k=>x.t.has(k.w)).length;if(c&&wantCert&&x.f.s.startsWith('Certificate:'))c+=0.5;if(c>bs){bs=c;best=x;}});
      if(!best)break;
      used.push(best.f);left.forEach(k=>{if(best.t.has(k.w))matched.add(k.w);});
      left=left.filter(k=>!best.t.has(k.w));
    }
    const missing=keys.filter(p=>!matched.has(p.w)).map(p=>p.o);
    const body=used.slice(0,2).map(f=>f.s).join(' ');
    const soft=used.some(f=>f.v==='partly');
    if(!missing.length) return soft?"Partly. "+body:(neg?"Actually, yes. ":"Yes. ")+body;
    if(matched.size) return "Partly. "+body+" I can't find "+[...new Set(missing)].join(', ')+" anywhere in the profile.";
    return (neg?"Correct, ":"No, ")+"I can't find "+[...new Set(missing)].join(', ')+" in Shashaank's CV, certificates, projects or internships. If it matters, email "+EMAIL+".";
  }

  let lastId=null;
  function retrieve(an,ql){
    const scored=[];
    const qt=an.map(p=>p.w);
    KBT.forEach(x=>{let s=0;qt.forEach(w=>{if(x.t.has(w))s+=1+Math.log(KBT.length/DF[w]);});if(s)scored.push({s,id:x.e.id,a:x.e.a});});
    CT.forEach((x,i)=>{let s=0;qt.forEach(w=>{if(x.t.has(w))s+=(DFC[w]>=4?1:3+Math.log(CT.length/DFC[w]));});if(s)scored.push({s,id:'cert'+i,a:certAnswer(CERTS[i])});});
    if(!scored.length)return null;
    scored.sort((a,b)=>b.s-a.s);
    lastId=scored[0].id;
    const out=[scored[0].a];
    if(scored[1]&&scored[1].s>=2&&scored[1].s>=scored[0].s*0.85&&scored[1].a!==scored[0].a)out.push(scored[1].a);
    return out.join('\n\n');
  }

  function reply(q){
    q=q.trim().slice(0,300);
    const ql=q.toLowerCase().replace(/\s+/g,' ');
    for(const [re,f] of SMALL) if(re.test(ql)){lastId=null;return f();}
    /* follow-ups */
    if(/^(tell me more|more( details| info)?|go on|continue|elaborate|and\??|what else|anything else|explain( more)?)[\s?!.]*$/.test(ql)){
      const e=KB.find(k=>k.id===lastId);
      if(e&&e.m)return e.m;
      return e?"That's everything I have on that topic. Try asking about education, skills, projects, internships or certificates.":"Sure, what would you like to know? I can cover education, skills, projects, internships and certificates.";
    }
    for(const [re,f] of RULES) if(re.test(ql)) return f();
    const an=analyse(q), toks=an.map(p=>p.w);
    /* counts and lists */
    let m;
    if((m=ql.match(/how many (certificat|certif|cert|project|internship|intern|language|credential)/))){
      const k=m[1];
      if(/cert|credential/.test(k)) return "Shashaank lists "+COUNTS.certs+" certificates on this portfolio.";
      if(/project/.test(k)) return COUNTS.projects+' project'+(COUNTS.projects===1?' is':'s are')+' listed: '+SITE.projects.map(p=>p.title).join(', ')+'.';
      if(/intern/.test(k)) return COUNTS.internships+' internship'+(COUNTS.internships===1?'':'s')+': '+SITE.internships.map(x=>x.title+(x.dur?' ('+x.dur+')':'')).join('; ')+'.';
      return "Two languages are listed on the CV: English and Hindi.";
    }
    if(/(certificates|certifications|certs|credentials)/.test(ql)&&/\b(list|all|every|name|show|which|what|display|give)\b/.test(ql)&&!isYesNo(ql)){lastId='certs';return certList(toks);}
    if(isYesNo(ql)){const r=yesNo(ql,an);if(r){return r;}}
    const r=retrieve(an,ql);
    if(r)return r;
    const ref=/\b(he|his|him|shashaank|sinha|you|your)\b/.test(ql);
    return ref?UNKNOWN:OUT;
  }
  /* ---------- Chat UI ---------- */
  const hist=[];
  async function answer(q){
    let a=null;
    if(USE_AI_FUNCTION){
      try{
        const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),10000);
        const r=await fetch('/.netlify/functions/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q,history:hist.slice(-6)}),signal:ctl.signal});
        clearTimeout(t);
        if(r.ok){const j=await r.json();if(j.answer)a=j.answer;}
      }catch(e){}
    }
    if(!a)a=reply(q);
    hist.push({role:'user',content:q},{role:'assistant',content:a});
    return a;
  }
  const chatPanel=document.getElementById('chatPanel'), log=document.getElementById('chatLog'), inp=document.getElementById('chatIn');
  function add(text,who){const d=document.createElement('div');d.className='msg '+who;d.style.whiteSpace='pre-wrap';d.textContent=text;log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
  let busy=false;
  async function ask(q){q=q.trim();if(!q||busy)return;busy=true;add(q,'me');inp.value='';const w=add('...','bot');const a=await answer(q);w.textContent=a;log.scrollTop=log.scrollHeight;busy=false;}
  document.getElementById('chatBtn').addEventListener('click',()=>{chatPanel.classList.toggle('open');if(chatPanel.classList.contains('open')){inp.focus();}});
  document.getElementById('chatX').addEventListener('click',()=>chatPanel.classList.remove('open'));
  document.getElementById('chatSend').addEventListener('click',()=>ask(inp.value));
  inp.addEventListener('keydown',e=>{if(e.key==='Enter')ask(inp.value);});
  add("Hi! Ask me anything about Shashaank: education, skills, projects, internships or certificates. Yes/no questions work too.",'bot');
  ['Which projects has Shashaank built?','Does Shashaank know Python?','Has Shashaank done any internships?','How can I contact Shashaank?'].forEach(q=>{const b=document.createElement('button');b.type='button';b.className='qchip';b.textContent=q;b.onclick=()=>ask(q);document.getElementById('chatChips').appendChild(b);});

  function internSummary(yes){
    const l=SITE.internships,list=l.map(x=>x.title+' ('+x.org+(x.start?', '+x.start+' to '+x.end:'')+')').join('; ');
    if(!l.length)return yes?'No work experience is listed yet.':'No full-time job is listed on the profile.';
    return (yes?'Yes, in the form of internships: ':'No full-time job is listed on the profile. The internships are: ')+list+'.';
  }
  function rebuildChat(){
    const d=SITE,nm=cap(d.hero.first)||'the owner';
    EMAIL=d.contact.email||'';PHONE=d.contact.phone||'';
    CERTS=d.certs.map((c,i)=>({t:c.title||'',i:c.issuer||'',d:c.date||'',cid:c.id||'',s:c.desc||'',n:i+1}));
    COUNTS={certs:d.certs.length,projects:d.projects.length,internships:d.internships.length,languages:2};
    PRIVATE="That's personal and isn't part of "+nm+"'s public portfolio, so I won't guess. I can help with education, skills, projects, internships, certificates or contact details.";
    OUT="That's outside what I can help with here. I only cover "+nm+"'s profile: education, skills, projects, internships, certificates and contact details.";
    UNKNOWN="I don't have that detail on "+nm+"'s profile."+(EMAIL?" You can email "+EMAIL+" to ask directly, or try":" Try")+" asking about education, skills, projects, internships or certificates.";
    SCOPE=" I can answer questions about "+nm+"'s education, skills, projects, internships and certificates.";
    const kb=(d.chat.kb||[]).map((x,i)=>({id:'kb'+i,k:x.k||'',a:x.a||'',m:x.m||''})).filter(x=>x.a);
    const facts=(d.chat.facts||[]).filter(f=>f.s).map(f=>({k:f.k||'',s:f.s,v:f.v||''}));
    if(d.projects.length)kb.push({id:'projects',k:'project projects work portfolio built made created develop',a:'Projects ('+d.projects.length+'): '+d.projects.map((p,i)=>'('+(i+1)+') '+p.title+(p.pill?', '+p.pill:'')+(p.label?' ('+p.label+')':'')).join('; ')+'.',m:'Ask about any of them by name.'});
    d.projects.forEach((p,i)=>{kb.push({id:'proj'+i,k:'project '+p.title+' '+(p.label||'')+' '+(p.pill||''),a:p.title+(p.label?' ('+p.label+')':'')+': '+(p.text||'')+(p.details?' '+p.details:'')+(p.link?' Link: '+p.link:'')});facts.push({k:'project '+p.title+' '+(p.label||''),s:'Project: '+p.title+'. '+(p.text||''),v:''});});
    if(d.internships.length)kb.push({id:'interns',k:'intern internship internships offer letter experience trainee',a:'Internships ('+d.internships.length+'): '+d.internships.map(n=>n.title+' ('+n.org+(n.start?', '+n.start+' to '+n.end:'')+(n.dur?', '+n.dur:'')+')').join('; ')+'. Offer letters can be opened in the Internships section.',m:'Ask about either one for the weekly tasks.'});
    d.internships.forEach((n,i)=>{kb.push({id:'intern'+i,k:'internship intern '+n.title+' '+n.org,a:n.title+' ('+n.org+(n.start?', '+n.start+' to '+n.end:'')+(n.dur?', '+n.dur:'')+').'+((n.weeks&&n.weeks.length)?' Weekly tasks: '+n.weeks.map((w,j)=>(j+1)+') '+w).join('; ')+'.':'')});facts.push({k:'intern internship '+n.title+' '+n.org,s:'Internship: '+n.title+' ('+n.org+(n.start?', '+n.start+' to '+n.end:'')+').',v:''});});
    if(d.certs.length)kb.push({id:'certs',k:'certificate certification credential credentials courses course badge qualified achievement achievements',a:nm+' lists '+d.certs.length+' certificates, including '+d.certs.slice(0,8).map(c=>c.title).join(', ')+'. Press "Show credentials" on any card to view it, or ask me to list them all.'});
    d.certs.forEach(c=>facts.push({k:(c.title||'')+' '+(c.issuer||''),s:'Certificate: '+c.title+(c.issuer?' from '+c.issuer:'')+(c.date?' (issued '+c.date+')':'')+'.',v:''}));
    kb.push({id:'contact',k:'contact email phone reach mail call number location live based where hire message talk connect',a:'Contact: '+[EMAIL,PHONE].filter(Boolean).join(' or ')+(d.contact.location?'. Based in '+d.contact.location+'.':'.')});
    kb.push({id:'site',k:'website site portfolio page section built sections navigate cv resume',a:'This portfolio has: About, Skills, Projects, Internships (with offer letters), Certifications (with credentials), LinkedIn posts and Contact.'});
    KB=kb;FACTS=facts;rebuildIndex();
  }


/* build the answers from the current data (site.js may already have rendered) */
if(typeof SITE!=='undefined'&&SITE&&SITE.hero&&typeof rebuildChat==='function')rebuildChat();
