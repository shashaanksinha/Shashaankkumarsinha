/* Public site runtime: renders every section from data/site-data.js */
/* ================= Portfolio runtime: every section is rendered from SITE data ================= */
const $=(s,r)=>(r||document).querySelector(s), $$=(s,r)=>Array.from((r||document).querySelectorAll(s));
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=o=>JSON.parse(JSON.stringify(o));
const cap=s=>String(s||'').replace(/^./,c=>c.toUpperCase());
const BASE=window.SITE_DATA||{};
let SITE=clone(BASE), PUBLISHED=BASE, HAS_DRAFT=false, INTRO={done:false,finish:function(){}};

const DB={
  open(){return new Promise((res,rej)=>{const r=indexedDB.open('sk-portfolio',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});},
  async get(k){try{const db=await this.open();return await new Promise(res=>{const q=db.transaction('kv').objectStore('kv').get(k);q.onsuccess=()=>res(q.result);q.onerror=()=>res(undefined);});}catch(e){return undefined;}},
  async set(k,v){const db=await this.open();return new Promise((res,rej)=>{const t=db.transaction('kv','readwrite');t.objectStore('kv').put(v,k);t.oncomplete=res;t.onerror=()=>rej(t.error);});},
  async del(k){try{const db=await this.open();return await new Promise(res=>{const t=db.transaction('kv','readwrite');t.objectStore('kv').delete(k);t.oncomplete=res;t.onerror=res;});}catch(e){}}
};

function normalize(d){
  const b=clone(BASE), out=Object.assign(b,d||{});
  ['profile','hero','about','headings','contact','settings','chat','intro'].forEach(k=>{out[k]=Object.assign({},BASE[k],(d&&d[k])||{});});
  ['marquee1','marquee2','skills','projects','internships','certs','extras','linkedin','badges'].forEach(k=>{if(!Array.isArray(out[k]))out[k]=clone(BASE[k]||[]);});
  out.chat.kb=Array.isArray(out.chat.kb)?out.chat.kb:clone(BASE.chat.kb);
  out.chat.facts=Array.isArray(out.chat.facts)?out.chat.facts:clone(BASE.chat.facts);
  return out;
}

/* ---------- files / modal ---------- */
function toBlobUrl(u){
  if(!/^data:/.test(u||''))return u;
  try{const i=u.indexOf(','),mime=u.slice(5,i).split(';')[0],bin=atob(u.slice(i+1)),arr=new Uint8Array(bin.length);for(let k=0;k<bin.length;k++)arr[k]=bin.charCodeAt(k);return URL.createObjectURL(new Blob([arr],{type:mime}));}catch(e){return u;}
}
const fileKind=f=>/^data:application\/pdf|\.pdf(\?|#|$)/i.test(f||'')?'pdf':'img';
function certSpec(c){if(!c||(!c.file&&!c.link))return null;const f=c.file,l=c.link;return{title:c.title,sub:[c.issuer,c.date].filter(Boolean).join(' · '),kind:f?fileKind(f):'frame',src:f||l,link:l||f};}
function internSpec(n){if(!n||!n.offerFile)return null;return{title:n.offerLabel||(n.title+' Offer Letter'),sub:n.title,kind:fileKind(n.offerFile),src:n.offerFile,link:n.offerFile};}
let lastFocus=null;
function openModal(s){
  if(!s)return;
  const modal=$('#modal'),mBody=$('#mBody');
  lastFocus=document.activeElement;
  $('#mTitle').textContent=s.title;$('#mSub').textContent=s.sub||'';
  const src=toBlobUrl(s.src),link=toBlobUrl(s.link||s.src);
  const a=$('#mOpen');a.href=link;a.textContent=(s.link&&s.link!==s.src)?'Verify online':'Open in new tab';
  const note=$('#mNote');mBody.innerHTML='';
  if(s.kind==='img'){
    const im=new Image();im.alt=s.title;im.src=src;
    im.onerror=()=>{mBody.innerHTML='<p class="p-8 text-center opacity-70">Certificate image coming soon.</p>';};
    mBody.appendChild(im);note.textContent='';
  }else{
    const f=document.createElement('iframe');f.title=s.title;
    f.src=s.kind==='pdf'?src+'#toolbar=0&view=FitH':src;mBody.appendChild(f);
    note.textContent=s.kind==='frame'?'Shown directly from the issuer. If the page stays blank, the issuer blocks embedding: use "Open in new tab".':'';
  }
  modal.classList.add('open');document.body.style.overflow='hidden';$('#mClose').focus();
}
function closeModal(){const m=$('#modal');if(!m)return;m.classList.remove('open');$('#mBody').innerHTML='';document.body.style.overflow='';if(lastFocus&&lastFocus.focus)lastFocus.focus();}
document.addEventListener('click',e=>{
  const c=e.target.closest&&e.target.closest('[data-cred]'),o=e.target.closest&&e.target.closest('[data-offer]');
  if(c)openModal(certSpec(SITE.certs[+c.dataset.cred]));
  else if(o)openModal(internSpec(SITE.internships[+o.dataset.offer]));
  else if(e.target.id==='modal')closeModal();
});
$('#mClose').addEventListener('click',closeModal);

/* ---------- fade-in on scroll ---------- */
let IO=null;
function observeFades(){
  if(!IO)IO=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');IO.unobserve(e.target);}}),{threshold:.12});
  $$('.fade:not(.show)').forEach(el=>IO.observe(el));
}

/* ---------- section renderers ---------- */
const CARD='rounded-[40px] sm:rounded-[50px] border-2 border-[#D7E2EA] p-6 md:p-8 flex flex-col gap-6 bg-[#0C0C0C]';
const PILL='ghost-btn rounded-full uppercase tracking-widest';
function renderHero(){
  const h=SITE.hero;
  $('#hH1').innerHTML=esc(h.line1)+'<br>'+esc(h.first)+'<br>'+esc(h.last);
  const img=$('#hImg');if(SITE.profile.photo&&img.getAttribute('src')!==SITE.profile.photo)img.src=SITE.profile.photo;img.alt=SITE.profile.name||'';
  $('#hTag').textContent=h.tagline;
}
function renderMarquee(){
  const row=(l,rev)=>{if(!l||!l.length)return'';const it=l.map(t=>'<span class="chip rounded-2xl px-6 py-8 text-lg">'+esc(t)+'</span>').join('');return'<div class="overflow-hidden"><div class="marquee-track'+(rev?' rev':'')+'">'+it+it+'</div></div>';};
  $('#rMarquee').innerHTML=row(SITE.marquee1,false)+row(SITE.marquee2,true);
}
function renderAbout(){$('#hdAbout').textContent=SITE.headings.about;$('#aText').textContent=SITE.about.text;}
function renderSkills(){
  $('#hdSkills').textContent=SITE.headings.skills;
  const n=SITE.skills.length;
  $('#rSkills').innerHTML=SITE.skills.map((s,i)=>'<div class="fade flex gap-6 md:gap-10 py-8 sm:py-10 md:py-12"'+(i<n-1?' style="border-bottom:1px solid rgba(12,12,12,.15)"':'')+'><span class="num" style="font-size:clamp(3rem,10vw,140px)">'+String(i+1).padStart(2,'0')+'</span><div><h3 class="font-medium uppercase" style="font-size:clamp(1rem,2.2vw,2.1rem)">'+esc(s.title)+'</h3><p class="font-light leading-relaxed max-w-2xl opacity-60" style="font-size:clamp(.85rem,1.6vw,1.25rem)">'+esc(s.text)+'</p></div></div>').join('');
}
function renderProjects(){
  $('#hdProjects').textContent=SITE.headings.projects;
  $('#rProjects').innerHTML=SITE.projects.map((p,i)=>'<div class="fade sticky-card" style="top:'+(96+28*Math.min(i,5))+'px"><div class="'+CARD+'"><div class="flex flex-wrap items-center justify-between gap-4"><span class="hero-heading font-black" style="font-size:clamp(2.5rem,8vw,100px)">'+String(i+1).padStart(2,'0')+'</span><div class="flex-1 min-w-[180px]"><p class="uppercase tracking-widest text-sm opacity-60">'+esc(p.label)+'</p><h3 class="uppercase font-medium text-xl md:text-2xl">'+esc(p.title)+'</h3></div>'+(p.pill?'<span class="'+PILL+' px-6 py-2 text-sm">'+esc(p.pill)+'</span>':'')+'</div><p class="opacity-70 max-w-2xl">'+esc(p.text)+'</p>'+(p.link?'<div><a href="'+esc(p.link)+'" target="_blank" rel="noopener" class="'+PILL+' px-6 py-2.5 text-sm inline-block">View project</a></div>':'')+'</div></div>').join('');
}
function renderInterns(){
  $('#hdInterns').textContent=SITE.headings.internships;
  $('#rInterns').innerHTML=SITE.internships.map((n,i)=>'<div class="fade '+CARD+'"><div class="flex flex-wrap items-center justify-between gap-4"><span class="hero-heading font-black" style="font-size:clamp(2.5rem,8vw,100px)">'+String(i+1).padStart(2,'0')+'</span><div class="flex-1 min-w-[200px]"><p class="uppercase tracking-widest text-sm opacity-60">'+esc(n.org)+'</p><h3 class="uppercase font-medium text-xl md:text-2xl">'+esc(n.title)+'</h3></div>'+(n.dur?'<span class="'+PILL+' px-6 py-2 text-sm">'+esc(n.dur)+'</span>':'')+'</div>'+((n.start||n.end)?'<p class="opacity-70 uppercase tracking-widest text-sm">Start: '+esc(n.start)+' &nbsp;·&nbsp; End: '+esc(n.end)+'</p>':'')+((n.weeks&&n.weeks.length)?'<ul class="flex flex-col gap-2 opacity-80">'+n.weeks.map((w,j)=>'<li class="flex gap-3"><span class="opacity-50 shrink-0 uppercase text-xs tracking-widest pt-1">Week '+(j+1)+'</span><span>'+esc(w)+'</span></li>').join('')+'</ul>':'')+(n.offerFile?'<div><button type="button" class="'+PILL+' px-6 py-2.5 text-sm" data-offer="'+i+'">Show offer letter</button></div>':'')+'</div>').join('');
}
function certCard(c,i,pos){
  const meta=[c.issuer,c.date?'Issued '+c.date:''].filter(Boolean).join(' · ')||'Certificate';
  const spec=certSpec(c),isImg=c.file&&fileKind(c.file)==='img';
  const thumb=spec?('<button type="button" data-cred="'+i+'" class="shrink-0 rounded-2xl overflow-hidden border border-[#2A2A2A] bg-white" style="width:96px;height:68px" aria-label="Open '+esc(c.title)+'">'+(isImg?'<img src="'+esc(c.file)+'" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover">':'<span class="flex items-center justify-center w-full h-full text-xs font-medium" style="color:#0C0C0C">'+(c.file?'PDF':'LINK')+'</span>')+'</button>'):'';
  const btn=spec?'<button type="button" class="'+PILL+' px-5 py-2 text-xs sm:text-sm" data-cred="'+i+'">Show credentials</button>':'';
  const verify=c.link?'<a href="'+esc(c.link)+'" target="_blank" rel="noopener" class="text-xs uppercase tracking-widest opacity-60 hover:opacity-100 underline">Verify</a>':'';
  return '<div class="fade sticky-card" style="top:'+(96+28*Math.min(pos,5))+'px"><div class="rounded-[30px] sm:rounded-[40px] border-2 border-[#D7E2EA] p-5 md:p-7 flex flex-wrap items-center gap-4 bg-[#0C0C0C]"><span class="hero-heading font-black" style="font-size:clamp(2rem,6vw,64px)">'+String(pos+1).padStart(2,'0')+'</span>'+thumb+'<div class="flex-1 min-w-[200px]"><p class="uppercase tracking-widest text-xs sm:text-sm opacity-60">'+esc(meta)+'</p><h3 class="uppercase font-medium text-lg md:text-2xl">'+esc(c.title)+'</h3>'+(c.desc?'<p class="opacity-70 text-sm mt-2 max-w-2xl">'+esc(c.desc)+'</p>':'')+(c.id?'<p class="text-xs opacity-50 mt-1 break-all">Credential ID: '+esc(c.id)+'</p>':'')+'</div><div class="flex items-center gap-4">'+verify+btn+'</div></div></div>';
}
function renderCerts(){
  $('#hdCerts').textContent=SITE.headings.certs;$('#hdCertsMore').textContent=SITE.headings.certsMore||'Additional Certificates';
  const groups={main:[],additional:[]};
  SITE.certs.forEach((c,i)=>{(c.group==='additional'?groups.additional:groups.main).push([c,i]);});
  $('#rCerts').innerHTML=groups.main.map((x,p)=>certCard(x[0],x[1],p)).join('');
  $('#rCertsMore').innerHTML=groups.additional.map((x,p)=>certCard(x[0],x[1],p)).join('');
  $('#certifications').style.display=groups.main.length?'':'none';
  $('#more-certificates').style.display=groups.additional.length?'':'none';
}
function renderExtras(){
  $('#rExtras').innerHTML=SITE.extras.map(x=>'<section class="bg-[#0C0C0C] px-5 sm:px-8 md:px-10 py-20 sm:py-24 text-center"><h2 class="fade hero-heading font-black uppercase mb-10" style="font-size:clamp(2.2rem,9vw,130px)">'+esc(x.title)+'</h2><div class="fade max-w-3xl mx-auto flex flex-col items-center gap-8">'+(x.image?'<img src="'+esc(x.image)+'" alt="'+esc(x.title)+'" class="rounded-[30px] max-w-full" style="max-height:520px;object-fit:cover">':'')+(x.text?'<p class="opacity-80 leading-relaxed whitespace-pre-line" style="font-size:clamp(1rem,2vw,1.35rem)">'+esc(x.text)+'</p>':'')+((x.btnLabel&&x.btnUrl)?'<a href="'+esc(x.btnUrl)+'" target="_blank" rel="noopener" class="contact-btn rounded-full text-white font-medium uppercase tracking-widest px-10 py-3.5 text-sm">'+esc(x.btnLabel)+'</a>':'')+'</div></section>').join('');
}
let CREDLY_TRIED=false;
function renderBadges(){
  $('#hdBadges').textContent=SITE.headings.badges||'Digital Badges';
  const list=(SITE.badges||[]).filter(b=>b&&b.badgeId);
  $('#badges').style.display=list.length?'':'none';
  $('#rBadges').innerHTML=list.map(b=>'<div class="rounded-3xl p-3 bg-white" style="min-width:'+(parseInt(b.width)||150)+'px"><div data-iframe-width="'+esc(b.width||150)+'" data-iframe-height="'+esc(b.height||270)+'" data-share-badge-id="'+esc(b.badgeId)+'" data-share-badge-host="'+esc(b.host||'https://www.credly.com')+'"></div></div>').join('');
  if(list.length){
    const old=document.getElementById('credlyEmbed');if(old)old.remove();
    const s=document.createElement('script');s.id='credlyEmbed';s.async=true;s.src='https://cdn.credly.com/assets/utilities/embed.js';document.body.appendChild(s);
  }
}
function liInfo(it){
  let u=String((it&&it.url)||'').trim();const m=u.match(/src=["']([^"']+)["']/);if(m)u=m[1];
  const urn=u.match(/urn:li:(share|ugcPost|activity):(\d+)/);let embed='',post='';
  if(urn){const q='urn:li:'+urn[1]+':'+urn[2];embed='https://www.linkedin.com/embed/feed/update/'+q+'?collapsed=1';post='https://www.linkedin.com/feed/update/'+q+'/';}
  else{const a=u.match(/activity-(\d{10,})/);if(a){embed='https://www.linkedin.com/embed/feed/update/urn:li:activity:'+a[1]+'?collapsed=1';post=u;}else if(/^https?:/.test(u)){embed=u;post=u;}}
  return{embed,post,h:parseInt(it&&it.height)||640};
}
function renderLinkedIn(){
  $('#hdLinkedin').textContent=SITE.headings.linkedin;
  $('#rLinkedin').innerHTML=SITE.linkedin.map(it=>{const l=liInfo(it);if(!l.embed)return'';return'<figure class="w-full" style="max-width:504px"><iframe src="'+esc(l.embed)+'" height="'+l.h+'" frameborder="0" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" title="Embedded LinkedIn post" style="width:100%;border-radius:20px;background:#fff"></iframe><figcaption class="text-center mt-4"><a class="'+PILL+' px-5 py-2 text-xs inline-block" href="'+esc(l.post)+'" target="_blank" rel="noopener">Open on LinkedIn</a></figcaption></figure>';}).join('');
  $('#linkedin').style.display=SITE.linkedin.some(it=>liInfo(it).embed)?'':'none';
}
function renderContact(){
  const c=SITE.contact;$('#hdContact').textContent=SITE.headings.contact;
  $('#rContact').innerHTML=(c.email?'<a href="mailto:'+esc(c.email)+'" class="'+PILL+' px-8 py-3 text-sm">'+esc(c.email)+'</a>':'')+(c.phone?'<a href="tel:'+esc(String(c.phone).replace(/[^+\d]/g,''))+'" class="'+PILL+' px-8 py-3 text-sm">'+esc(c.phone)+'</a>':'');
  $('#rFooter').textContent=c.footer||'';
}
const ART={
  projects:'<svg viewBox="0 0 120 70" preserveAspectRatio="xMidYMid slice"><rect width="120" height="70" fill="#fff6ea"/><rect x="10" y="8" width="42" height="26" rx="4" fill="#fff" stroke="#f0d5b8"/><rect x="58" y="8" width="52" height="26" rx="4" fill="#fff" stroke="#f0d5b8"/><g fill="#e8854b"><rect x="16" y="22" width="6" height="8"/><rect x="26" y="17" width="6" height="13"/><rect x="36" y="12" width="6" height="18"/></g><polyline points="64,28 76,20 88,24 104,13" fill="none" stroke="#7a4cc9" stroke-width="2.4" stroke-linecap="round"/><rect x="10" y="40" width="100" height="22" rx="4" fill="#fff" stroke="#f0d5b8"/><g fill="#c8789a"><rect x="16" y="46" width="30" height="4" rx="2"/><rect x="16" y="54" width="52" height="4" rx="2" opacity=".6"/></g><circle cx="96" cy="51" r="7" fill="none" stroke="#e8854b" stroke-width="4" stroke-dasharray="26 18"/></svg>',
  skills:'<svg viewBox="0 0 120 70" preserveAspectRatio="xMidYMid slice"><rect width="120" height="70" fill="#fff0f2"/><g stroke="#ef5d7a" fill="none" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><rect x="10" y="14" width="22" height="22" rx="3"/><path d="M10 25h22M21 14v22"/><path d="M44 36v-8m6 8V20m6 16v-12m6 12V16"/><ellipse cx="88" cy="20" rx="12" ry="5"/><path d="M76 20v14c0 3 5.4 5 12 5s12-2 12-5V20M76 27c0 3 5.4 5 12 5s12-2 12-5"/></g><path d="M30 58l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" transform="translate(48 -22) scale(.9)" fill="#f7b060"/><path d="M92 50l2 4.5 4.5 2-4.5 2-2 4.5-2-4.5-4.5-2 4.5-2z" fill="#7a4cc9"/></svg>'
};
function fillThumbs(){
  const set=(id,html)=>{const e=$('#'+id);if(e)e.innerHTML=html;};
  const img=(src,cls)=>'<img class="'+(cls||'')+'" src="'+esc(src)+'" alt="" onerror="this.remove()">';
  const I=SITE.intro||{};
  const certImg=I.certs||((SITE.certs.find(c=>c.group!=='additional'&&c.file&&fileKind(c.file)==='img')||SITE.certs.find(c=>c.file&&fileKind(c.file)==='img')||{}).file);
  const projImg=I.projects||((SITE.projects.find(p=>p.image)||{}).image);
  set('thP',projImg?img(projImg):ART.projects);
  set('thI',I.internships?img(I.internships,'contain'):'');
  set('thC',certImg?img(certImg):'');
  set('thS',I.skills?img(I.skills):ART.skills);
}
function renderIntroText(){
  if(!$('#intro'))return;
  const h=SITE.hero;
  $('#dxHi').textContent=cap(h.line1).replace(/'/g,'\u2019');
  $('#dxSub').textContent=String(h.last||'').toUpperCase();
  $('#dxBlurb').textContent=cap(h.tagline||'');
  const nm=$('#dxName');nm.innerHTML='';
  const t=(performance.now()||0)/1000;
  String(h.first||'').toUpperCase().split('').forEach((c,i)=>{const sp=document.createElement('span');sp.textContent=c===' '?'\u00a0':c;sp.style.animationDelay=Math.max(0,2.5+i*0.07-t).toFixed(2)+'s';nm.appendChild(sp);});
  nm.setAttribute('aria-label',h.first||'');
  $('#dxP').textContent=SITE.projects.length+' built';$('#dxI').textContent=SITE.internships.length+' remote';$('#dxC').textContent=SITE.certs.length+' earned';
  fillThumbs();
}
function renderAll(){
  document.title=SITE.settings.pageTitle||document.title;
  renderHero();renderMarquee();renderAbout();renderSkills();renderProjects();renderInterns();renderCerts();renderBadges();renderExtras();renderLinkedIn();renderContact();renderIntroText();
  observeFades();
  if(typeof rebuildChat==='function')rebuildChat();
}

/* ---------- intro animation ---------- */
function startIntro(){
  const intro=$('#intro');if(!intro){INTRO.done=true;return;}
  function finish(){
    if(INTRO.done)return;INTRO.done=true;
    document.documentElement.classList.remove('intro-lock');document.body.classList.add('intro-done');intro.classList.add('out');
    setTimeout(()=>{if(intro.parentNode)intro.remove();},900);
  }
  INTRO.finish=finish;window.__introFinish=finish;
  $('#introSkip').addEventListener('click',finish);
  if((window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)||SITE.settings.introEnabled===false){finish();return;}
  try{
    let s=42;const rnd=()=>(s=(s*16807)%2147483647)/2147483647;
    let st='';for(let i=0;i<18;i++){st+='<i style="left:'+(rnd()*100).toFixed(1)+'%;top:'+(rnd()*36).toFixed(1)+'%;width:'+(1+rnd()*2).toFixed(1)+'px;height:'+(1+rnd()*2).toFixed(1)+'px"></i>';}
    $('#dxStars').innerHTML=st;
    const layer=(id,minH,maxH,minW,maxW,fill,windows,skipCenter,op)=>{
      let x=-10,svg='';
      while(x<1010){
        const w=minW+rnd()*(maxW-minW),hh=minH+rnd()*(maxH-minH);
        if(!(skipCenter&&x+w>425&&x<575)){
          svg+='<rect x="'+x.toFixed(1)+'" y="'+(300-hh).toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+hh.toFixed(1)+'" fill="'+fill+'" opacity="'+op+'"/>';
          if(rnd()>.78)svg+='<rect x="'+(x+w/2).toFixed(1)+'" y="'+(300-hh-16).toFixed(1)+'" width="1.6" height="16" fill="'+fill+'" opacity="'+op+'"/>';
          if(windows)for(let wy=300-hh+6;wy<292;wy+=9)for(let wx=x+4;wx<x+w-5;wx+=7)if(rnd()>.55)svg+='<rect x="'+wx.toFixed(1)+'" y="'+wy.toFixed(1)+'" width="2.4" height="3.4" fill="#ffd9a3" opacity="'+(.45+rnd()*.5).toFixed(2)+'"/>';
        }
        x+=w+rnd()*4;
      }
      $('#'+id).innerHTML=svg;
    };
    layer('dxBack',60,170,22,52,'#6a5aa3',false,false,.55);
    layer('dxFront',28,105,24,58,'#141c4a',true,true,1);
  }catch(e){finish();return;}
  setTimeout(finish,10400);
}

/* ---------- boot: published data (data/site-data.js) + this browser's unpublished draft ---------- */
async function boot(){
  PUBLISHED=normalize(BASE);SITE=clone(PUBLISHED);
  const draft=await DB.get('draft');
  if(draft&&draft.data&&String(draft.data.updated||'')>String(BASE.updated||'')){SITE=normalize(draft.data);HAS_DRAFT=true;}
  if(SITE.settings.introEnabled===false&&!INTRO.done)INTRO.finish();
  renderAll();
  if(HAS_DRAFT)showDraftBadge();
  track();
}
function showDraftBadge(){
  const b=document.createElement('a');b.href='admin/';b.textContent='Unpublished draft preview. Open Studio';
  b.style.cssText='position:fixed;left:16px;bottom:16px;z-index:70;background:#fff;color:#0C0C0C;border-radius:999px;padding:8px 14px;font-size:.72rem;letter-spacing:.06em;text-transform:uppercase;box-shadow:0 6px 20px rgba(0,0,0,.4)';
  document.body.appendChild(b);
}
/* anonymous visit counter (country-level only, needs the Netlify function; silently skipped elsewhere) */
function track(){
  try{
    if(HAS_DRAFT||navigator.doNotTrack==='1'||/^(localhost|127\.|file)/.test(location.hostname||'file'))return;
    if(sessionStorage.getItem('sk-v'))return;sessionStorage.setItem('sk-v','1');
    const body=JSON.stringify({p:location.pathname,r:document.referrer?new URL(document.referrer).hostname:''});
    if(navigator.sendBeacon)navigator.sendBeacon('/.netlify/functions/track',new Blob([body],{type:'application/json'}));
    else fetch('/.netlify/functions/track',{method:'POST',body,keepalive:true});
  }catch(e){}
}
startIntro();
boot();
