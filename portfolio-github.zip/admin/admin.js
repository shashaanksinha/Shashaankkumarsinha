/* Studio: login + dashboard for the portfolio. Plain JavaScript, no build step. */
(function(){
'use strict';
const $=(s,r)=>(r||document).querySelector(s), $$=(s,r)=>Array.from((r||document).querySelectorAll(s));
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=o=>JSON.parse(JSON.stringify(o));
const cap=s=>String(s||'').replace(/^./,c=>c.toUpperCase());
function H(tag,attrs){
  const e=document.createElement(tag);
  for(const k in (attrs||{})){const v=attrs[k];if(v===false||v==null)continue;
    if(k==='class')e.className=v;else if(k==='html')e.innerHTML=v;else if(k.slice(0,2)==='on')e.addEventListener(k.slice(2),v);else e.setAttribute(k,v===true?'':v);}
  for(let i=2;i<arguments.length;i++){const c=arguments[i];(Array.isArray(c)?c:[c]).forEach(x=>{if(x==null||x===false)return;e.append(x.nodeType?x:document.createTextNode(x));});}
  return e;
}
function sha256hex(str){
  const bytes=new TextEncoder().encode(str);
  const K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
  const H=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  const l=bytes.length,nb=((l+9+63)>>6)<<6,m=new Uint8Array(nb);m.set(bytes);m[l]=0x80;
  const dv=new DataView(m.buffer);dv.setUint32(nb-4,(l*8)>>>0);dv.setUint32(nb-8,Math.floor(l*8/4294967296));
  const w=new Uint32Array(64);
  for(let o=0;o<nb;o+=64){
    for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);
    for(let i=16;i<64;i++){const a=w[i-15],b=w[i-2];const s0=((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3);const s1=((b>>>17)|(b<<15))^((b>>>19)|(b<<13))^(b>>>10);w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0;}
    let a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
    for(let i=0;i<64;i++){const S1=((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7));const ch=(e&f)^(~e&g);const t1=(h+S1+ch+K[i]+w[i])>>>0;const S0=((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10));const mj=(a&b)^(a&c)^(b&c);const t2=(S0+mj)>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}
    H[0]=(H[0]+a)>>>0;H[1]=(H[1]+b)>>>0;H[2]=(H[2]+c)>>>0;H[3]=(H[3]+d)>>>0;H[4]=(H[4]+e)>>>0;H[5]=(H[5]+f)>>>0;H[6]=(H[6]+g)>>>0;H[7]=(H[7]+h)>>>0;
  }
  return Array.from(H).map(x=>x.toString(16).padStart(8,'0')).join('');
}

/* ---------- icons ---------- */
const IC={
 home:'<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
 folder:'<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>',
 brief:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2M3 13h18"/>',
 award:'<circle cx="12" cy="9" r="6"/><path d="M8.5 14L7 22l5-3 5 3-1.5-8"/>',
 badge:'<path d="M12 2l3 2.5 3.8.4.4 3.8L22 12l-2.8 3.3-.4 3.8-3.8.4L12 22l-3-2.5-3.8-.4-.4-3.8L2 12l2.8-3.3.4-3.8L9 4.5z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
 layers:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5M3 17l9 5 9-5"/>',
 chart:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
 spark:'<path d="M12 3l2.2 5.8L20 11l-5.8 2.2L12 19l-2.2-5.8L4 11l5.8-2.2zM19 3v4M17 5h4"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
 chat:'<path d="M21 12a8 8 0 01-11.6 7.1L3 21l1.9-5.4A8 8 0 1121 12z"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
 edit:'<path d="M4 20h4L19 9l-4-4L4 16zM14 6l4 4"/>',
 trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
 up:'<path d="M12 19V5M5 12l7-7 7 7"/>',
 down:'<path d="M12 5v14M19 12l-7 7-7-7"/>',
 eye:'<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
 up2:'<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
 ext:'<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1h5"/>',
 menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',
 out:'<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>',
 pin:'<path d="M12 22s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>',
 close:'<path d="M6 6l12 12M18 6L6 18"/>'
};
const icon=(n,sz)=>{const s=document.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('viewBox','0 0 24 24');s.setAttribute('fill','none');s.setAttribute('stroke','currentColor');s.setAttribute('stroke-width','1.8');s.setAttribute('stroke-linecap','round');s.setAttribute('stroke-linejoin','round');if(sz){s.setAttribute('width',sz);s.setAttribute('height',sz);}s.innerHTML=IC[n]||'';return s;};

/* ---------- storage: unpublished draft lives in this browser (shared with the site preview) ---------- */
const DB={
  open(){return new Promise((res,rej)=>{const r=indexedDB.open('sk-portfolio',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});},
  async get(k){try{const db=await this.open();return await new Promise(res=>{const q=db.transaction('kv').objectStore('kv').get(k);q.onsuccess=()=>res(q.result);q.onerror=()=>res(undefined);});}catch(e){return undefined;}},
  async set(k,v){const db=await this.open();return new Promise((res,rej)=>{const t=db.transaction('kv','readwrite');t.objectStore('kv').put(v,k);t.oncomplete=res;t.onerror=()=>rej(t.error);});},
  async del(k){try{const db=await this.open();return await new Promise(res=>{const t=db.transaction('kv','readwrite');t.objectStore('kv').delete(k);t.oncomplete=res;t.onerror=res;});}catch(e){}}
};
const LS={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}},del(k){try{localStorage.removeItem(k);}catch(e){}}};

/* ---------- data ---------- */
const BASE=window.SITE_DATA||{};
function normalize(d){
  const out=Object.assign(clone(BASE),clone(d||{}));
  ['profile','hero','about','headings','contact','settings','chat','intro'].forEach(k=>{out[k]=Object.assign({},BASE[k]||{},(d&&d[k])||{});});
  ['marquee1','marquee2','skills','projects','internships','certs','extras','linkedin','badges'].forEach(k=>{if(!Array.isArray(out[k]))out[k]=clone(BASE[k]||[]);});
  out.chat.kb=Array.isArray(out.chat.kb)?out.chat.kb:[];out.chat.facts=Array.isArray(out.chat.facts)?out.chat.facts:[];
  out.certs.forEach(c=>{if(!c.group)c.group='main';});
  return out;
}
let PUB=normalize(BASE),S=clone(PUB),HAS_DRAFT=false;
const strip=d=>{const c=clone(d);delete c.updated;return JSON.stringify(c);};
const isDirty=()=>strip(S)!==strip(PUB);


/* ---------- toast / dialog ---------- */
let toastT=0;
function toast(t){const e=$('#toast');e.textContent=t;e.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>{e.hidden=true;},2600);}
function openDlg(node){const d=$('#dlg');d.innerHTML='';d.append(H('div',{class:'box'},node));d.hidden=false;d.onclick=e=>{if(e.target===d&&!d.dataset.lock)closeDlg();};}
function closeDlg(){const d=$('#dlg');d.hidden=true;d.innerHTML='';delete d.dataset.lock;}

/* ---------- saving ---------- */
let saveT=0,statT=0;
async function saveDraft(){
  try{await DB.set('draft',{data:S,savedAt:Date.now(),schema:S.schema});HAS_DRAFT=true;}
  catch(e){toast('Could not save the draft in this browser. Publish soon or use smaller images.');}
  updateStatus();
}
function commit(){
  S.updated=new Date().toISOString();
  clearTimeout(saveT);saveT=setTimeout(saveDraft,350);
  clearTimeout(statT);statT=setTimeout(updateStatus,120);
}
function updateStatus(){
  const el=$('#stat');if(!el)return;
  const d=isDirty();el.textContent=d?'Unpublished changes':'All changes published';el.className='status '+(d?'dirty':'ok');
}

/* ---------- files ---------- */
function readFile(file,f){
  return new Promise((res,rej)=>{
    if(file.type==='application/pdf'){
      if(file.size>3.5*1024*1024)return rej(new Error('That PDF is larger than 3.5 MB. Please compress it first.'));
      const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(new Error('Could not read the file'));r.readAsDataURL(file);return;
    }
    if(!file.type.startsWith('image/'))return rej(new Error('Please choose an image'+(f.pdf?' or a PDF':'')+'.'));
    const url=URL.createObjectURL(file),img=new Image();
    img.onload=()=>{
      const max=f.max||1600;let w=img.naturalWidth,h=img.naturalHeight;const s=Math.min(1,max/Math.max(w,h));w=Math.round(w*s);h=Math.round(h*s);
      const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0,w,h);
      URL.revokeObjectURL(url);res(c.toDataURL('image/jpeg',f.q||.86));
    };
    img.onerror=()=>rej(new Error('Could not read that image'));img.src=url;
  });
}
const isImgSrc=v=>/^data:image|\.(png|jpe?g|webp|gif|svg)(\?|$)/i.test(v||'');
const resolveSrc=v=>/^(data:|https?:|blob:|\/)/.test(v||'')?v:'../'+v;   // site-relative paths -> from /admin/

/* ---------- form fields ---------- */
function field(obj,f,onChange){
  const ch=()=>{onChange&&onChange();};
  const wrap=H('div',{class:'fld'+(f.type==='check'?' chk':'')});
  const lab=H('label',{},f.label);
  const hint=f.hint?H('div',{class:'hint'},f.hint):null;
  const get=()=>obj[f.key];
  if(f.type==='check'){
    const i=H('input',{type:'checkbox',id:'f_'+f.key});i.checked=!!get();i.onchange=()=>{obj[f.key]=i.checked;ch();};
    lab.setAttribute('for','f_'+f.key);wrap.append(i,lab);if(hint)wrap.append(hint);return wrap;
  }
  wrap.append(lab);
  if(f.type==='textarea'||f.type==='lines'){
    const t=H('textarea',{rows:f.rows||4,placeholder:f.ph||''});
    t.value=f.type==='lines'?(Array.isArray(get())?get().join('\n'):''):(get()||'');
    t.oninput=()=>{obj[f.key]=f.type==='lines'?t.value.split('\n').map(x=>x.trim()).filter(Boolean):t.value;ch();};
    wrap.append(t);
  }else if(f.type==='select'){
    const s=H('select');(f.options||[]).forEach(o=>s.append(H('option',{value:o[0]},o[1])));s.value=get()||f.options[0][0];
    s.onchange=()=>{obj[f.key]=s.value;ch();};wrap.append(s);
  }else if(f.type==='file'){
    const box=H('div',{class:'file'}),pv=H('div',{class:'pv'+(f.round?' round':'')});
    const info=H('div',{}),name=H('small'),input=H('input',{type:'file',accept:f.accept||'image/*',hidden:true});
    const draw=()=>{const v=get();pv.innerHTML='';
      if(!v){pv.textContent='No file';name.textContent='';}
      else{if(isImgSrc(v))pv.append(H('img',{src:resolveSrc(v),alt:''}));else pv.textContent=/pdf/i.test(v)?'PDF':'FILE';
        name.textContent=v.indexOf('data:')===0?'New upload ('+Math.round(v.length*0.75/1024)+' KB), goes live when you publish':v;}};
    const pick=H('button',{type:'button',class:'btn sm',onclick:()=>input.click()},'Choose file');
    const clr=H('button',{type:'button',class:'btn sm',onclick:()=>{obj[f.key]='';draw();ch();}},'Remove');
    input.onchange=async()=>{const file=input.files[0];if(!file)return;try{obj[f.key]=await readFile(file,f);draw();ch();}catch(e){toast(e.message);}input.value='';};
    info.append(H('div',{class:'row'},pick,clr),name);box.append(pv,info,input);draw();wrap.append(box);
  }else{
    const i=H('input',{type:f.type||'text',placeholder:f.ph||''});i.value=get()==null?'':get();
    i.oninput=()=>{obj[f.key]=f.type==='number'?i.value:i.value;ch();};wrap.append(i);
  }
  if(hint)wrap.append(hint);return wrap;
}

/* ---------- side drawer (add / edit one item) ---------- */
function closeDrawer(){$('#drawer').hidden=true;$('#scrim').hidden=true;$('#drawer').innerHTML='';}
function openDrawer(cfg){
  const d=$('#drawer'),item=clone(cfg.item);d.innerHTML='';
  const body=H('div',{class:'body'});
  cfg.fields.forEach(f=>body.append(field(item,f)));
  const save=H('button',{type:'button',class:'btn pri',onclick:()=>{
    if(cfg.validate){const m=cfg.validate(item);if(m){toast(m);return;}}
    cfg.onSave(item);closeDrawer();}},cfg.saveLabel||'Save');
  d.append(H('header',{},H('h2',{},cfg.title),H('button',{type:'button',class:'ico',onclick:closeDrawer,'aria-label':'Close'},icon('close'))),
    body,H('footer',{},H('button',{type:'button',class:'btn',onclick:closeDrawer},'Cancel'),save));
  d.hidden=false;$('#scrim').hidden=false;$('#scrim').onclick=closeDrawer;
  const first=$('input[type=text],textarea',body);if(first)setTimeout(()=>first.focus(),50);
}

/* ---------- login scene (same generator as the site intro) ---------- */
function drawScene(){
  let s=42;const rnd=()=>(s=(s*16807)%2147483647)/2147483647;
  let st='';for(let i=0;i<22;i++)st+='<i style="left:'+(rnd()*100).toFixed(1)+'%;top:'+(rnd()*36).toFixed(1)+'%;width:'+(1+rnd()*2).toFixed(1)+'px;height:'+(1+rnd()*2).toFixed(1)+'px"></i>';
  $('#lgStars').innerHTML=st;
  const layer=(id,minH,maxH,minW,maxW,fill,win,skip,op)=>{
    let x=-10,svg='';
    while(x<1010){const w=minW+rnd()*(maxW-minW),hh=minH+rnd()*(maxH-minH);
      if(!(skip&&x+w>425&&x<575)){
        svg+='<rect x="'+x.toFixed(1)+'" y="'+(300-hh).toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+hh.toFixed(1)+'" fill="'+fill+'" opacity="'+op+'"/>';
        if(rnd()>.78)svg+='<rect x="'+(x+w/2).toFixed(1)+'" y="'+(300-hh-16).toFixed(1)+'" width="1.6" height="16" fill="'+fill+'" opacity="'+op+'"/>';
        if(win)for(let wy=300-hh+6;wy<292;wy+=9)for(let wx=x+4;wx<x+w-5;wx+=7)if(rnd()>.55)svg+='<rect x="'+wx.toFixed(1)+'" y="'+wy.toFixed(1)+'" width="2.4" height="3.4" fill="#ffd9a3" opacity="'+(.45+rnd()*.5).toFixed(2)+'"/>';}
      x+=w+rnd()*4;}
    $('#'+id).innerHTML=svg;
  };
  layer('lgBack',60,170,22,52,'#6a5aa3',false,false,.55);layer('lgFront',28,105,24,58,'#141c4a',true,true,1);
}

/* ---------- sign in (client-side lock; real protection is the GitHub token + admin token) ---------- */
function loginHash(user,pw,st){let h=sha256hex(st.adminSalt+':'+String(user).trim().toLowerCase()+':'+pw);for(let i=0;i<(st.adminIter||0);i++)h=sha256hex(h+st.adminSalt);return h;}
function checkLogin(user,pw){return [PUB.settings,S.settings].some(st=>st&&st.adminHash&&st.adminSalt&&loginHash(user,pw,st)===st.adminHash);}
const sessionOk=()=>{const t=+sessionStorage.getItem('sk-studio')||0;return t>Date.now();};
function startLogin(){
  drawScene();
  const form=$('#lgForm'),err=$('#lgErr'),btn=$('#lgBtn');
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const f=LS.get('sk-fail',{n:0,until:0}),now=Date.now();
    if(f.until>now){err.textContent='Too many tries. Wait '+Math.ceil((f.until-now)/1000)+' seconds.';return;}
    btn.disabled=true;err.textContent='';
    setTimeout(()=>{
      let ok=false;try{ok=checkLogin($('#lgUser').value,$('#lgPass').value);}catch(x){}
      btn.disabled=false;
      if(ok){LS.del('sk-fail');sessionStorage.setItem('sk-studio',String(Date.now()+8*3600*1000));$('#lgPass').value='';enterStudio();}
      else{const n=f.n+1;LS.set('sk-fail',{n,until:n>=3?now+Math.min(300,Math.pow(2,n-2))*1000:0});err.textContent='User name or password is not right.';form.classList.remove('shake');void form.offsetWidth;form.classList.add('shake');}
    },30);
  });
  $('#lgUser').focus();
}


/* ---------- connection settings (kept only in this browser) ---------- */
const ghCfg=()=>Object.assign({owner:'',repo:'',branch:'main',token:''},LS.get('sk-gh',{}));
const adminTok=()=>LS.get('sk-admintoken','');
const slug=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40);
function hash8(str){let h=0x811c9dc5;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,0x01000193);}return (h>>>0).toString(16).padStart(8,'0');}

/* ---------- publish: one atomic commit to GitHub (Git Data API) ---------- */
function buildPublish(){
  const pub=clone(S),files=[],seen={};
  const ext={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','application/pdf':'pdf'};
  const walk=o=>{
    if(Array.isArray(o)){o.forEach(walk);return;}
    if(!o||typeof o!=='object')return;
    for(const k of Object.keys(o)){
      const v=o[k];
      if(typeof v==='string'&&v.indexOf('data:')===0){
        const m=v.match(/^data:([^;,]+);base64,([\s\S]*)$/);if(!m)continue;
        const path='assets/uploads/'+(slug(o.title||o.name||k)||k)+'-'+hash8(v)+'.'+(ext[m[1]]||'bin');
        if(!seen[path]){seen[path]=1;files.push({path,content:m[2],encoding:'base64'});}
        o[k]=path;
      }else walk(v);
    }
  };
  walk(pub);pub.updated=new Date().toISOString();
  const js='/* Edited by the Studio dashboard. You can also edit it by hand. */\nwindow.SITE_DATA = '+JSON.stringify(pub,null,1)+';\n';
  files.push({path:'data/site-data.js',content:js,encoding:'utf-8'});
  return {pub,files};
}
async function gh(cfg,path,opt){
  opt=opt||{};
  const r=await fetch('https://api.github.com/repos/'+cfg.owner+'/'+cfg.repo+path,{method:opt.method||'GET',body:opt.body,headers:Object.assign({Authorization:'Bearer '+cfg.token,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'},opt.body?{'Content-Type':'application/json'}:{})});
  let j={};try{j=await r.json();}catch(e){}
  if(!r.ok){const m=j.message||('GitHub error '+r.status);throw new Error([401,403,404].includes(r.status)?m+'. Check the owner, repository and branch names, and that the token has "Contents: Read and write" for this repository.':m);}
  return j;
}
function downloadText(name,text,type){const a=H('a',{href:URL.createObjectURL(new Blob([text],{type:type||'text/plain'})),download:name});document.body.append(a);a.click();a.remove();}
function downloadDataFile(){
  const out=clone(S);out.updated=new Date().toISOString();
  downloadText('site-data.js','/* Edited by the Studio dashboard. */\nwindow.SITE_DATA = '+JSON.stringify(out,null,1)+';\n','text/javascript');
}
async function doPublish(){
  const cfg=ghCfg();
  if(!cfg.owner||!cfg.repo||!cfg.token){
    openDlg(H('div',{},H('h2',{},'Connect GitHub to publish'),
      H('p',{class:'note'},'Publishing saves your changes to your GitHub repository, and your host (Netlify or GitHub Pages) then updates the live site. You only set this up once.'),
      H('ol',{class:'note'},H('li',{},'On GitHub open Settings, Developer settings, Fine-grained tokens, and create a token for your portfolio repository with "Contents: Read and write".'),H('li',{},'Open Studio Settings and paste the owner, repository name, branch and token.'),H('li',{},'Press Publish again.')),
      H('div',{class:'row'},H('button',{class:'btn pri',onclick:()=>{closeDlg();go('settings');}},'Open settings'),H('button',{class:'btn',onclick:()=>{downloadDataFile();}},'Download data file instead'),H('button',{class:'btn',onclick:closeDlg},'Close'))));
    return;
  }
  const {pub,files}=buildPublish(),uploads=files.length-1;
  const names=['Prepare '+files.length+' file'+(files.length>1?'s':'')+(uploads?' ('+uploads+' new upload'+(uploads>1?'s':'')+')':''),'Connect to GitHub','Upload files','Save changes to the repository','Done'];
  const lis=names.map(n=>H('li',{},n));const out=H('div',{class:'note'});
  const mark=(i,cls,t)=>{lis[i].className=cls;if(t)lis[i].textContent=t;};
  $('#dlg').dataset.lock='1';
  openDlg(H('div',{},H('h2',{},'Publishing'),H('ul',{class:'steps'},lis),out));
  $('#dlg').dataset.lock='1';
  let step=0;
  try{
    mark(0,'done');step=1;
    const ref=await gh(cfg,'/git/ref/heads/'+encodeURIComponent(cfg.branch));
    const parent=ref.object.sha;
    const pc=await gh(cfg,'/git/commits/'+parent);
    mark(1,'done');step=2;
    const tree=[];
    for(const f of files){
      const b=await gh(cfg,'/git/blobs',{method:'POST',body:JSON.stringify({content:f.content,encoding:f.encoding})});
      tree.push({path:f.path,mode:'100644',type:'blob',sha:b.sha});
    }
    mark(2,'done');step=3;
    const t=await gh(cfg,'/git/trees',{method:'POST',body:JSON.stringify({base_tree:pc.tree.sha,tree})});
    const c=await gh(cfg,'/git/commits',{method:'POST',body:JSON.stringify({message:'Update portfolio from Studio',tree:t.sha,parents:[parent]})});
    await gh(cfg,'/git/refs/heads/'+encodeURIComponent(cfg.branch),{method:'PATCH',body:JSON.stringify({sha:c.sha})});
    mark(3,'done');mark(4,'done');
    S.updated=pub.updated;PUB=clone(S);await saveDraft();updateStatus();
    out.textContent='Published. Your host rebuilds the site now, so the live page usually updates within one or two minutes.';
    out.append(H('div',{class:'row',style:'margin-top:12px'},H('a',{class:'btn pri',href:'../index.html',target:'_blank',rel:'noopener'},'Open site'),H('button',{class:'btn',onclick:closeDlg},'Close')));
  }catch(e){
    mark(step,'err',names[step]+': '+e.message);
    out.append(H('p',{},'Nothing was changed on the live site. Your edits are still saved in this browser.'),H('div',{class:'row'},H('button',{class:'btn',onclick:()=>{closeDlg();go('settings');}},'Open settings'),H('button',{class:'btn',onclick:()=>{downloadDataFile();}},'Download data file'),H('button',{class:'btn',onclick:closeDlg},'Close')));
  }
}

/* ---------- shell ---------- */
const ROUTES=[['dashboard','Dashboard','home'],['profile','Profile','user'],['projects','Projects','folder'],['interns','Internships','brief'],['certs','Certificates','award'],['badges','Digital badges','badge'],['content','More content','layers'],['sep'],['visitors','Visitors','chart'],['assistant','Ask Claude','spark'],['settings','Settings','gear']];
const ADM={route:'dashboard',q:'',tabs:{},adders:{}};
function go(r){location.hash='#/'+r;}
function buildSide(){
  const side=$('#side');side.innerHTML='';
  const nav=H('nav',{class:'nav'});
  ROUTES.forEach(r=>{
    if(r[0]==='sep'){nav.append(H('div',{class:'sep'}));return;}
    const a=H('a',{href:'#/'+r[0],'data-r':r[0],onclick:()=>side.classList.remove('open')},icon(r[2]),r[1]);nav.append(a);
  });
  side.append(H('div',{class:'me'},H('img',{class:'av',src:resolveSrc(S.profile.photo),alt:'',id:'meImg'}),H('b',{id:'meName'},S.profile.name||'Your portfolio'),H('small',{},'Your portfolio')),nav,
    H('a',{class:'nav-foot btn sm',href:'../index.html',target:'_blank',rel:'noopener',style:'margin:6px 8px;justify-content:center'},icon('eye'),'View site'),
    H('button',{class:'btn sm',style:'margin:0 8px 6px;justify-content:center',onclick:signOut},icon('out'),'Sign out'));
}
function buildTop(){
  const top=$('#top');top.innerHTML='';
  const q=H('input',{type:'search',placeholder:'Search in this page',id:'q','aria-label':'Search'});
  q.oninput=()=>{ADM.q=q.value.toLowerCase();renderRoute(true);};
  const createMenu=H('div',{class:'menu',hidden:true});
  [['Add certificate','certs'],['Add project','projects'],['Add internship','interns'],['Add digital badge','badges'],['Add LinkedIn post','content']].forEach(a=>createMenu.append(H('button',{type:'button',onclick:()=>{createMenu.hidden=true;go(a[1]);setTimeout(()=>{const f=ADM.adders[a[1]];f&&f(a[0]==='Add LinkedIn post'?'linkedin':null);},30);}},a[0])));
  const create=H('div',{class:'rel'},H('button',{type:'button',class:'btn',onclick:e=>{e.stopPropagation();createMenu.hidden=!createMenu.hidden;}},icon('plus'),'Create'),createMenu);
  document.addEventListener('click',()=>{createMenu.hidden=true;});
  top.append(H('button',{class:'ico menu-btn',onclick:()=>$('#side').classList.toggle('open'),'aria-label':'Menu'},icon('menu')),
    H('div',{class:'search'},icon('search'),q),H('div',{class:'sp'}),H('span',{id:'stat',class:'status hide-sm'},''),create,
    H('button',{id:'pubBtn',class:'btn pri',onclick:doPublish},icon('up2'),'Publish'));
  updateStatus();
}
function signOut(){sessionStorage.removeItem('sk-studio');location.hash='';$('#studio').hidden=true;$('#login').hidden=false;$('#lgUser').focus();}
function renderRoute(keepScroll){
  const r=(location.hash.replace(/^#\//,'')||'dashboard');
  const route=ROUTES.find(x=>x[0]===r)?r:'dashboard';ADM.route=route;
  $$('#side .nav a').forEach(a=>a.classList.toggle('on',a.dataset.r===route));
  const page=$('#page');const y=keepScroll?window.scrollY:0;
  page.innerHTML='';ADM.adders={};
  const fn=PAGES[route];page.append(fn());
  if(keepScroll)window.scrollTo(0,y);else window.scrollTo(0,0);
  const sb=$('#q');if(sb){sb.parentNode.style.display=['certs','projects','interns','badges','content'].includes(route)?'':'none';if(!keepScroll)sb.value=ADM.q='';}
}
function enterStudio(){
  $('#login').hidden=true;$('#studio').hidden=false;
  buildSide();buildTop();renderRoute();
}


/* ---------- generic list page (table + add/edit drawer), like the Studio "Content" tab ---------- */
function listPage(o){
  const host=H('div');
  const tabId=()=>ADM.tabs[o.key]||(o.tabs&&o.tabs[0].id);
  function visible(){
    const arr=o.arr();let vis=arr.map((_,i)=>i);
    if(o.tabs){const t=o.tabs.find(x=>x.id===tabId());vis=vis.filter(i=>t.filter(arr[i]));}
    if(ADM.q)vis=vis.filter(i=>String(o.search?o.search(arr[i]):arr[i].title||'').toLowerCase().includes(ADM.q));
    return vis;
  }
  function edit(i){
    const arr=o.arr(),isNew=i==null,item=isNew?o.blank(tabId()):arr[i];
    openDrawer({title:(isNew?'Add ':'Edit ')+o.noun,item,fields:o.fields,validate:o.validate,saveLabel:isNew?'Add':'Save',onSave:it=>{
      if(o.beforeSave)o.beforeSave(it);
      if(isNew)arr.push(it);else arr[i]=it;
      commit();draw();toast(isNew?cap(o.noun)+' added':'Saved');
    }});
  }
  function del(i){const it=o.arr()[i];if(!confirm('Delete "'+(it.title||o.noun)+'"? You can still discard the draft before publishing.'))return;o.arr().splice(i,1);commit();draw();}
  function move(i,dir,vis){const k=vis.indexOf(i),j=vis[k+dir];if(j==null)return;const a=o.arr();[a[i],a[j]]=[a[j],a[i]];commit();draw();}
  function draw(){
    host.innerHTML='';
    const arr=o.arr(),vis=visible();
    host.append(H('div',{class:'row',style:'justify-content:space-between;margin-bottom:6px'},H('h1',{class:'h1',style:'margin:0'},o.title),H('button',{class:'btn pri',onclick:()=>edit(null)},icon('plus'),'Add '+o.noun)));
    if(o.lead)host.append(H('p',{class:'lead'},o.lead));
    if(o.tabs){
      const tb=H('div',{class:'tabs'});
      o.tabs.forEach(t=>tb.append(H('button',{class:tabId()===t.id?'on':'',onclick:()=>{ADM.tabs[o.key]=t.id;draw();}},t.label,H('i',{},String(arr.filter(t.filter).length)))));
      host.append(tb);
    }
    if(!vis.length){host.append(H('div',{class:'tbl-wrap'},H('div',{class:'empty'},ADM.q?'Nothing matches your search.':'Nothing here yet. Press "Add '+o.noun+'".')));return;}
    const tr0=H('tr',{},o.cols.map(c=>H('th',{},c.h)),H('th',{}));
    const tbody=H('tbody');
    vis.forEach((i,k)=>{
      const it=arr[i];
      const acts=H('td',{class:'act'});
      (o.extra?o.extra(it,i,draw):[]).forEach(n=>acts.append(n));
      acts.append(H('button',{class:'ico',title:'Move up',disabled:k===0,onclick:()=>move(i,-1,vis)},icon('up')),H('button',{class:'ico',title:'Move down',disabled:k===vis.length-1,onclick:()=>move(i,1,vis)},icon('down')),H('button',{class:'ico',title:'Edit',onclick:()=>edit(i)},icon('edit')),H('button',{class:'ico',title:'Delete',onclick:()=>del(i)},icon('trash')));
      const tr=H('tr',{},o.cols.map(c=>H('td',{},c.r(it,i))),acts);
      tr.ondblclick=()=>edit(i);tbody.append(tr);
    });
    host.append(H('div',{class:'tbl-wrap'},H('table',{class:'tbl'},H('thead',{},tr0),tbody)));
  }
  ADM.adders[o.key]=()=>edit(null);
  draw();return host;
}
const thumbOf=v=>v&&isImgSrc(v)?H('img',{src:resolveSrc(v),alt:'',loading:'lazy'}):H('div',{class:'ph'},v?(/pdf/i.test(v)?'PDF':'FILE'):'none');
const titleCell=(img,title,sub)=>H('div',{class:'li'},thumbOf(img),H('div',{},H('b',{},title||'Untitled'),H('span',{class:'muted',style:'font-size:.78rem'},sub||'')));

/* ---------- page: Profile ---------- */
function card(title,...kids){return H('section',{class:'card'},H('h3',{},title),kids);}
function pageProfile(){
  const ch=()=>{commit();};
  const meSync=()=>{const i=$('#meImg');if(i)i.src=resolveSrc(S.profile.photo);const n=$('#meName');if(n)n.textContent=S.profile.name||'Your portfolio';};
  const wrap=H('div',{},H('h1',{class:'h1'},'Profile'),H('p',{class:'lead'},'Your name, photo and the text visitors read first. Changes appear on your site after you press Publish.'));
  const g=H('div',{class:'grid two'});
  g.append(
    card('Photo and name',
      field(S.profile,{key:'photo',label:'Profile picture',type:'file',round:true,max:900,q:.88,hint:'Shown on the home page and in this dashboard.'},()=>{ch();meSync();}),
      field(S.profile,{key:'name',label:'Full name'},()=>{ch();meSync();}),
      field(S.hero,{key:'line1',label:'Greeting line',ph:"hi, i'm"},ch),field(S.hero,{key:'first',label:'First name (big text)'},ch),field(S.hero,{key:'last',label:'Last name (big text)'},ch),
      field(S.hero,{key:'tagline',label:'One-line tagline',type:'textarea',rows:2},ch)),
    card('About me',field(S.about,{key:'text',label:'About text',type:'textarea',rows:8},ch),field(S.headings,{key:'about',label:'Section heading'},ch)),
    card('Contact',field(S.contact,{key:'email',label:'Email',type:'email'},ch),field(S.contact,{key:'phone',label:'Phone'},ch),field(S.contact,{key:'location',label:'Location'},ch),field(S.contact,{key:'footer',label:'Footer line'},ch),field(S.headings,{key:'contact',label:'Section heading'},ch)),
    card('Scrolling skill chips',H('p',{class:'note'},'One chip per line. Two rows scroll in opposite directions.'),field(S,{key:'marquee1',label:'Row 1',type:'lines',rows:6},ch),field(S,{key:'marquee2',label:'Row 2',type:'lines',rows:6},ch)),
    card('Section headings',...[['skills','What I do'],['projects','Projects'],['internships','Internships'],['certs','Certificates'],['certsMore','Additional certificates'],['badges','Digital badges'],['linkedin','LinkedIn']].map(x=>field(S.headings,{key:x[0],label:x[1]},ch))),
    card('Browser tab',field(S.settings,{key:'pageTitle',label:'Page title'},ch))
  );
  wrap.append(g);return wrap;
}

/* ---------- list pages ---------- */
function projectsPage(){return listPage({key:'projects',title:'Projects',noun:'project',arr:()=>S.projects,
  lead:'Each project is a stacking card on your site.',
  fields:[{key:'title',label:'Project name'},{key:'label',label:'Label above the name',ph:'Academic Project · 2025'},{key:'pill',label:'Small tag',ph:'Coursework'},{key:'text',label:'Short description',type:'textarea',rows:3},{key:'details',label:'More details (used by the chat box)',type:'textarea',rows:5},{key:'link',label:'Link (optional)',type:'url'},{key:'image',label:'Picture (optional)',type:'file',max:1400}],
  blank:()=>({label:'',title:'',pill:'',text:'',details:'',link:'',image:''}),validate:it=>it.title.trim()?'':'Please give the project a name.',
  search:p=>[p.title,p.label,p.text].join(' '),
  cols:[{h:'Project',r:p=>titleCell(p.image,p.title,p.label)},{h:'Tag',r:p=>p.pill?H('span',{class:'tag'},p.pill):''},{h:'Description',r:p=>H('span',{class:'muted'},(p.text||'').slice(0,90))}]});}
function internsPage(){return listPage({key:'interns',title:'Internships',noun:'internship',arr:()=>S.internships,
  lead:'Weekly tasks and the offer letter people can open from your site.',
  fields:[{key:'title',label:'Role'},{key:'org',label:'Company / place',ph:'YuvaIntern · Remote'},{key:'start',label:'Start date'},{key:'end',label:'End date'},{key:'dur',label:'Duration',ph:'4 weeks'},{key:'weeks',label:'Weekly tasks (one per line)',type:'lines',rows:6},{key:'offerFile',label:'Offer letter (PDF or image)',type:'file',accept:'application/pdf,image/*',pdf:true},{key:'offerLabel',label:'Offer letter title (optional)'}],
  blank:()=>({title:'',org:'',start:'',end:'',dur:'',weeks:[],offerFile:'',offerLabel:''}),validate:it=>it.title.trim()?'':'Please enter the role.',
  search:n=>[n.title,n.org].join(' '),
  cols:[{h:'Role',r:n=>titleCell('',n.title,n.org)},{h:'Dates',r:n=>H('span',{class:'muted'},[n.start,n.end].filter(Boolean).join(' to '))},{h:'Duration',r:n=>n.dur?H('span',{class:'tag'},n.dur):''},{h:'Offer letter',r:n=>n.offerFile?H('span',{class:'tag'},'Attached'):H('span',{class:'muted'},'None')}]});}
const GROUP_LABEL={main:'Certificates',additional:'Additional'};
function certsPage(){return listPage({key:'certs',title:'Certificates',noun:'certificate',arr:()=>S.certs,
  lead:'Top picks go in "Certificates"; everything else goes in "Additional certificates". Both keep the stacking scroll animation.',
  tabs:[{id:'main',label:'Certificates',filter:c=>c.group!=='additional'},{id:'additional',label:'Additional certificates',filter:c=>c.group==='additional'},{id:'all',label:'All',filter:()=>true}],
  fields:[{key:'title',label:'Certificate name'},{key:'issuer',label:'Issued by'},{key:'date',label:'Date issued',ph:'Sep 2026'},{key:'id',label:'Credential ID (optional)'},{key:'desc',label:'Short description',type:'textarea',rows:3},{key:'file',label:'Certificate image or PDF',type:'file',accept:'image/*,application/pdf',pdf:true,hint:'Opens inside your site when someone presses Show credentials.'},{key:'link',label:'Verify link (optional)',type:'url',ph:'https://...',hint:'Shown as "Verify" on the card.'},{key:'group',label:'Section',type:'select',options:[['main','Certificates (top picks)'],['additional','Additional certificates']]}],
  blank:t=>({title:'',issuer:'',date:'',id:'',desc:'',file:'',link:'',group:t==='additional'?'additional':'main'}),validate:it=>it.title.trim()?'':'Please enter the certificate name.',
  search:c=>[c.title,c.issuer,c.date,c.desc].join(' '),
  extra:(c,i,draw)=>[H('button',{class:'ico',title:c.group==='additional'?'Move to Certificates':'Move to Additional certificates',onclick:()=>{c.group=c.group==='additional'?'main':'additional';commit();draw();toast('Moved to '+(c.group==='additional'?'Additional certificates':'Certificates'));}},icon('layers'))],
  cols:[{h:'Certificate',r:c=>titleCell(c.file,c.title,c.issuer)},{h:'Section',r:c=>H('span',{class:'tag '+(c.group==='additional'?'additional':'main')},GROUP_LABEL[c.group==='additional'?'additional':'main'])},{h:'Date',r:c=>H('span',{class:'muted'},c.date||'')},{h:'Verify link',r:c=>c.link?H('a',{href:c.link,target:'_blank',rel:'noopener',class:'muted'},'Link'):H('span',{class:'muted'},'None')}]});}
function parseBadge(code){
  const g=(n)=>{const m=String(code||'').match(new RegExp(n+'\\s*=\\s*["\\\']([^"\\\']+)["\\\']','i'));return m?m[1]:'';};
  return {badgeId:g('data-share-badge-id'),host:g('data-share-badge-host'),width:g('data-iframe-width'),height:g('data-iframe-height')};
}
function badgesPage(){return listPage({key:'badges',title:'Digital badges',noun:'badge',arr:()=>S.badges,
  lead:'Credly badges are embedded in their own section. Paste the embed code Credly gives you.',
  fields:[{key:'title',label:'Badge name (for your reference)'},{key:'embed',label:'Paste the Credly embed code',type:'textarea',rows:5,hint:'Or leave this empty and fill the fields below.'},{key:'badgeId',label:'Badge ID'},{key:'host',label:'Credly host',ph:'https://www.credly.com'},{key:'width',label:'Width',type:'number'},{key:'height',label:'Height',type:'number'}],
  blank:()=>({title:'',embed:'',badgeId:'',host:'https://www.credly.com',width:'150',height:'270'}),
  validate:it=>{const p=parseBadge(it.embed);if(p.badgeId){it.badgeId=p.badgeId;if(p.host)it.host=p.host;if(p.width)it.width=p.width;if(p.height)it.height=p.height;}return it.badgeId?'':'Paste the embed code or enter the badge ID.';},
  beforeSave:it=>{delete it.embed;if(!it.title)it.title='Digital badge';},
  search:b=>[b.title,b.badgeId].join(' '),
  cols:[{h:'Badge',r:b=>titleCell('',b.title,b.badgeId)},{h:'Size',r:b=>H('span',{class:'muted'},(b.width||150)+' x '+(b.height||270))},{h:'On Credly',r:b=>H('a',{class:'muted',target:'_blank',rel:'noopener',href:(b.host||'https://www.credly.com')+'/badges/'+b.badgeId},'Open')}]});}
function contentPage(){
  const subs=[
   {id:'skills',label:'What I do',cfg:{key:'content-skills',title:'What I do',noun:'skill block',arr:()=>S.skills,lead:'Numbered rows in the white section.',fields:[{key:'title',label:'Heading'},{key:'text',label:'Text',type:'textarea',rows:4}],blank:()=>({title:'',text:''}),validate:it=>it.title.trim()?'':'Please enter a heading.',search:s=>s.title+' '+s.text,cols:[{h:'Heading',r:s=>titleCell('',s.title,'')},{h:'Text',r:s=>H('span',{class:'muted'},(s.text||'').slice(0,100))}]}},
   {id:'linkedin',label:'LinkedIn posts',cfg:{key:'content-linkedin',title:'LinkedIn posts',noun:'LinkedIn post',arr:()=>S.linkedin,lead:'Paste the post link or the full embed code. The post must be public for LinkedIn to allow embedding.',fields:[{key:'url',label:'Post link or embed code',type:'textarea',rows:4},{key:'height',label:'Height in pixels',type:'number'}],blank:()=>({url:'',height:'640'}),validate:it=>it.url.trim()?'':'Paste the post link.',search:p=>p.url,cols:[{h:'Post',r:p=>titleCell('',(p.url||'').replace(/<[^>]+>/g,' ').slice(0,70),'')},{h:'Height',r:p=>H('span',{class:'muted'},p.height||'')}]}},
   {id:'extras',label:'Extra sections',cfg:{key:'content-extras',title:'Extra sections',noun:'section',arr:()=>S.extras,lead:'Free-form sections shown above LinkedIn: a heading, picture, text and an optional button.',fields:[{key:'title',label:'Heading'},{key:'text',label:'Text',type:'textarea',rows:5},{key:'image',label:'Picture',type:'file'},{key:'btnLabel',label:'Button text (optional)'},{key:'btnUrl',label:'Button link',type:'url'}],blank:()=>({title:'',text:'',image:'',btnLabel:'',btnUrl:''}),validate:it=>it.title.trim()?'':'Please enter a heading.',search:x=>x.title+' '+x.text,cols:[{h:'Section',r:x=>titleCell(x.image,x.title,'')},{h:'Text',r:x=>H('span',{class:'muted'},(x.text||'').slice(0,90))}]}},
   {id:'kb',label:'Chat answers',cfg:{key:'content-kb',title:'Chat box answers',noun:'answer',arr:()=>S.chat.kb,lead:'Ready-made answers for the visitor chat box. Projects, internships, certificates and contact details are added automatically.',fields:[{key:'k',label:'Keywords (words a visitor might use)',type:'textarea',rows:2},{key:'a',label:'Answer',type:'textarea',rows:5},{key:'m',label:'Extra detail for "tell me more" (optional)',type:'textarea',rows:3}],blank:()=>({k:'',a:'',m:''}),validate:it=>it.a.trim()?'':'Please write the answer.',search:x=>x.k+' '+x.a,cols:[{h:'Keywords',r:x=>H('b',{},(x.k||'').slice(0,50))},{h:'Answer',r:x=>H('span',{class:'muted'},(x.a||'').slice(0,100))}]}},
   {id:'facts',label:'Yes/no facts',cfg:{key:'content-facts',title:'Facts for yes/no questions',noun:'fact',arr:()=>S.chat.facts,lead:'"Does Shashaank know X?" is answered Yes when X appears in a fact.',fields:[{key:'k',label:'Keywords',type:'textarea',rows:2},{key:'s',label:'One short sentence',type:'textarea',rows:3},{key:'v',label:'Answer "Partly" instead of "Yes"',type:'check'}],blank:()=>({k:'',s:'',v:''}),beforeSave:it=>{it.v=it.v?'partly':'';},validate:it=>it.s.trim()?'':'Please write the sentence.',search:x=>x.k+' '+x.s,cols:[{h:'Keywords',r:x=>H('b',{},(x.k||'').slice(0,50))},{h:'Sentence',r:x=>H('span',{class:'muted'},(x.s||'').slice(0,100))}]}}
  ];
  const host=H('div'),inner=H('div');
  function draw(){
    host.innerHTML='';
    const cur=ADM.tabs.content||'skills';
    const tb=H('div',{class:'tabs'});subs.forEach(s=>tb.append(H('button',{class:cur===s.id?'on':'',onclick:()=>{ADM.tabs.content=s.id;draw();}},s.label)));
    host.append(tb);
    const s=subs.find(x=>x.id===cur)||subs[0];host.append(listPage(s.cfg));
  }
  draw();
  ADM.adders.content=kind=>{if(kind){ADM.tabs.content=kind;draw();}const f=ADM.adders['content-'+(ADM.tabs.content||'skills')];f&&f();};
  return H('div',{},H('h1',{class:'h1'},'More content'),H('p',{class:'lead'},'Everything else that appears on the site.'),host);
}


/* ---------- visitors (needs the Netlify "stats" function) ---------- */
async function loadStats(force){
  if(!force&&ADM.stats&&Date.now()-ADM.stats.t<60000)return ADM.stats.d;
  const tok=adminTok();if(!tok){const e=new Error('notoken');e.code='notoken';throw e;}
  let r;try{r=await fetch('/.netlify/functions/stats',{headers:{'x-admin-token':tok}});}catch(x){const e=new Error('offline');e.code='nofn';throw e;}
  if(r.status===401||r.status===403){const e=new Error('Wrong admin token');e.code='badtoken';throw e;}
  const txt=await r.text();let j;try{j=JSON.parse(txt);}catch(x){const e=new Error('nofn');e.code='nofn';throw e;}
  if(!r.ok){const e=new Error(j.error||'Error '+r.status);e.code='err';throw e;}
  ADM.stats={t:Date.now(),d:j};return j;
}
const flag=cc=>/^[A-Za-z]{2}$/.test(cc||'')?String.fromCodePoint(...[...cc.toUpperCase()].map(c=>127397+c.charCodeAt(0))):'🌐';
function statsProblem(e){
  const m={notoken:['Add your admin token','Open Settings and paste the admin token you set in Netlify (ADMIN_TOKEN). It is saved only in this browser.'],badtoken:['That admin token was not accepted','Check the token in Settings matches the ADMIN_TOKEN value in Netlify.'],nofn:['Visitor tracking is not running yet','It needs the Netlify functions that come in this project. Deploy the repository on Netlify (see README), then this page fills in as people visit.'],err:['Could not load visitors',e&&e.message||'Unknown error']}[e&&e.code]||['Could not load visitors',e&&e.message||''];
  return H('div',{class:'empty'},H('b',{},m[0]),H('p',{class:'note'},m[1]),H('button',{class:'btn',onclick:()=>go('settings')},'Open settings'));
}
function ago(t){const s=Math.max(1,Math.round((Date.now()-t)/1000));if(s<60)return s+'s ago';if(s<3600)return Math.round(s/60)+' min ago';if(s<86400)return Math.round(s/3600)+' h ago';return Math.round(s/86400)+' d ago';}
function loadLeaflet(){return new Promise((res,rej)=>{if(window.L)return res();document.head.append(H('link',{rel:'stylesheet',href:'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css'}));const s=H('script',{src:'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js'});s.onload=res;s.onerror=()=>rej(new Error('map'));document.head.append(s);});}
function pageVisitors(){
  const wrap=H('div',{},H('h1',{class:'h1'},'Visitors'),H('p',{class:'lead'},'Where people are viewing your portfolio from. Counts are anonymous: only country and city are stored, never IP addresses.'));
  const body=H('div',{},H('div',{class:'empty'},'Loading...'));wrap.append(body);
  loadStats(true).then(d=>{
    body.innerHTML='';
    const days=d.days||{},keys=[];for(let i=27;i>=0;i--){const t=new Date(Date.now()-i*864e5).toISOString().slice(0,10);keys.push(t);}
    const vals=keys.map(k=>days[k]||0),max=Math.max(1,...vals),last7=vals.slice(-7).reduce((a,b)=>a+b,0),last28=vals.reduce((a,b)=>a+b,0);
    body.append(H('div',{class:'grid',style:'margin-bottom:18px'},
      H('div',{class:'card'},H('h3',{},'Views'),H('div',{class:'stats'},
        H('div',{class:'stat'},H('b',{},String(d.total||0)),H('span',{},'All time')),H('div',{class:'stat'},H('b',{},String(last28)),H('span',{},'Last 28 days')),
        H('div',{class:'stat'},H('b',{},String(last7)),H('span',{},'Last 7 days')),H('div',{class:'stat'},H('b',{},String((d.countries||[]).length)),H('span',{},'Countries')))),
      H('div',{class:'card'},H('h3',{},'Last 28 days'),H('div',{class:'bars'},vals.map((v,i)=>H('i',{style:'height:'+Math.max(2,Math.round(v/max*100))+'%',title:keys[i]+': '+v}))))));
    const cmax=Math.max(1,...(d.countries||[]).map(c=>c.count));
    const countries=H('div',{},(d.countries||[]).slice(0,12).map(c=>H('div',{class:'crow'},H('span',{},flag(c.code)),H('div',{},H('div',{},c.name||c.code),H('div',{class:'bar'},H('i',{style:'width:'+Math.round(c.count/cmax*100)+'%'}))),H('b',{},String(c.count)))));
    const cities=H('div',{class:'list'},(d.cities||[]).slice(0,12).map(c=>H('div',{class:'li'},H('span',{},flag(c.cc)),H('div',{},H('b',{},c.city||'Unknown city'),H('span',{class:'muted',style:'font-size:.78rem'},c.country||'')),H('b',{style:'margin-left:auto'},String(c.count)))));
    const recent=H('div',{class:'list'},(d.recent||[]).slice(0,12).map(v=>H('div',{class:'li'},H('span',{},flag(v.cc)),H('div',{},H('b',{},[v.city,v.cc].filter(Boolean).join(', ')||'Unknown'),H('span',{class:'muted',style:'font-size:.78rem'},v.ref?'from '+v.ref:'direct')),H('span',{class:'muted',style:'margin-left:auto;font-size:.78rem'},ago(v.t)))));
    const mapBox=H('div',{id:'map'},'');
    body.append(H('div',{class:'card',style:'margin-bottom:18px'},H('h3',{},'Where visitors are',H('small',{},'city-level, approximate')),mapBox),
      H('div',{class:'grid'},card('Top countries',countries),card('Top cities',cities),card('Latest visits',recent)));
    const pts=(d.cities||[]).filter(c=>typeof c.lat==='number'&&typeof c.lon==='number');
    loadLeaflet().then(()=>{
      const m=L.map(mapBox,{worldCopyJump:true}).setView([20,10],2);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{attribution:'&copy; OpenStreetMap contributors &copy; CARTO',maxZoom:8}).addTo(m);
      const grp=pts.map(p=>L.circleMarker([p.lat,p.lon],{radius:6+Math.sqrt(p.count)*3,color:'#f7b060',weight:1,fillColor:'#ef5d7a',fillOpacity:.65}).bindTooltip((p.city||'Unknown')+', '+(p.country||'')+' · '+p.count).addTo(m));
      if(grp.length)m.fitBounds(L.featureGroup(grp).getBounds().pad(.4),{maxZoom:5});
    }).catch(()=>{mapBox.textContent='The map could not load (it needs internet). The lists below still work.';mapBox.className='empty';mapBox.style.height='auto';});
  }).catch(e=>{body.innerHTML='';body.append(H('div',{class:'card'},statsProblem(e)));});
  return wrap;
}

/* ---------- Claude assistant (agentic: it can edit the draft through tools) ---------- */
const AI={msgs:[],log:[],busy:false,snaps:[],pending:''};
const ALLOWED={projects:['label','title','pill','text','details','link'],internships:['title','org','start','end','dur','weeks','offerLabel'],certs:['title','issuer','date','id','desc','link','group'],badges:['title','badgeId','host','width','height'],skills:['title','text'],extras:['title','text','btnLabel','btnUrl'],linkedin:['url','height']};
const BLANKS={projects:()=>({label:'',title:'',pill:'',text:'',details:'',link:'',image:''}),internships:()=>({title:'',org:'',start:'',end:'',dur:'',weeks:[],offerFile:'',offerLabel:''}),certs:()=>({title:'',issuer:'',date:'',id:'',desc:'',file:'',link:'',group:'main'}),badges:()=>({title:'Digital badge',badgeId:'',host:'https://www.credly.com',width:'150',height:'270'}),skills:()=>({title:'',text:''}),extras:()=>({title:'',text:'',image:'',btnLabel:'',btnUrl:''}),linkedin:()=>({url:'',height:'640'})};
const NOUN={projects:'project',internships:'internship',certs:'certificate',badges:'badge',skills:'skill block',extras:'section',linkedin:'LinkedIn post'};
const COLL=n=>({projects:S.projects,internships:S.internships,certs:S.certs,badges:S.badges,skills:S.skills,extras:S.extras,linkedin:S.linkedin}[n]);
function compact(){
  const c=clone(S);delete c.chat;delete c.settings;delete c.intro;delete c.schema;c.profile={name:S.profile.name};
  ['projects','internships','certs','badges','skills','extras','linkedin'].forEach(k=>{c[k]=(c[k]||[]).map((x,i)=>Object.assign({index:i},x));});
  return JSON.parse(JSON.stringify(c,(k,v)=>typeof v==='string'?(v.indexOf('data:')===0?'[uploaded file]':(v.length>260?v.slice(0,260)+'...':v)):v));
}
function applyTool(name,a,log){
  a=a||{};
  switch(name){
    case 'get_site_data':return compact();
    case 'update_profile':{
      const map={name:[S.profile,'name'],hero_line1:[S.hero,'line1'],hero_first:[S.hero,'first'],hero_last:[S.hero,'last'],tagline:[S.hero,'tagline'],about_text:[S.about,'text'],email:[S.contact,'email'],phone:[S.contact,'phone'],location:[S.contact,'location'],footer:[S.contact,'footer'],page_title:[S.settings,'pageTitle']};
      const done=[];for(const k in a){if(map[k]&&typeof a[k]==='string'){map[k][0][map[k][1]]=a[k];done.push(k);}}
      if(!done.length)throw new Error('No known profile fields given');log.push('Updated profile: '+done.join(', '));return {ok:true,updated:done};}
    case 'upsert_item':{
      const arr=COLL(a.collection);if(!arr)throw new Error('Unknown collection '+a.collection);
      const f=a.fields||{},allow=ALLOWED[a.collection],clean={};
      allow.forEach(k=>{if(f[k]!=null)clean[k]=(k==='weeks'?(Array.isArray(f[k])?f[k].map(String):String(f[k]).split('\n')):String(f[k]));});
      if(a.collection==='certs'&&clean.group&&!['main','additional'].includes(clean.group))clean.group='main';
      if(a.index==null){const it=Object.assign(BLANKS[a.collection](),clean);arr.push(it);log.push('Added '+NOUN[a.collection]+': '+(it.title||it.url||it.badgeId||'item'));return {ok:true,index:arr.length-1,count:arr.length};}
      if(!arr[a.index])throw new Error('No item at index '+a.index);
      Object.assign(arr[a.index],clean);log.push('Updated '+NOUN[a.collection]+' #'+a.index+': '+(arr[a.index].title||''));return {ok:true,index:a.index};}
    case 'delete_item':{
      const arr=COLL(a.collection);if(!arr||!arr[a.index])throw new Error('No such item');
      const t=arr[a.index].title||'';arr.splice(a.index,1);log.push('Deleted '+NOUN[a.collection]+': '+t);return {ok:true,count:arr.length};}
    case 'move_item':{
      const arr=COLL(a.collection);if(!arr||!arr[a.from]||a.to<0||a.to>=arr.length)throw new Error('Invalid positions');
      const [it]=arr.splice(a.from,1);arr.splice(a.to,0,it);log.push('Moved '+NOUN[a.collection]+' '+(it.title||'')+' to position '+a.to);return {ok:true};}
    case 'set_chips':{
      const k=a.row===2?'marquee2':'marquee1';if(!Array.isArray(a.items))throw new Error('items must be a list');
      S[k]=a.items.map(String);log.push('Updated skill chips row '+(a.row===2?2:1));return {ok:true};}
    case 'set_heading':{
      if(!(a.key in S.headings))throw new Error('Unknown heading '+a.key);S.headings[a.key]=String(a.value);log.push('Renamed heading '+a.key);return {ok:true};}
  }
  throw new Error('Unknown tool '+name);
}
async function callAI(){
  const t=adminTok();if(!t)throw new Error('Add your admin token in Settings first.');
  let msgs=AI.msgs.slice(-30);while(msgs.length&&!(msgs[0].role==='user'&&typeof msgs[0].content==='string'))msgs.shift();
  let r;try{r=await fetch('/.netlify/functions/admin-ai',{method:'POST',headers:{'Content-Type':'application/json','x-admin-token':t},body:JSON.stringify({messages:msgs,summary:compact()})});}catch(e){throw new Error('Could not reach the server. Claude runs through a Netlify function (see README).');}
  const txt=await r.text();let j;try{j=JSON.parse(txt);}catch(e){throw new Error(r.status===404?'The Claude function is not deployed yet. It runs on Netlify (see README).':'Unexpected reply from the server.');}
  if(!r.ok)throw new Error(j.error||('Error '+r.status));return j;
}
async function runAI(text,redraw){
  AI.busy=true;AI.log.push({k:'me',t:text});AI.msgs.push({role:'user',content:text});redraw();
  const snap=clone(S);let changed=false;
  try{
    for(let n=0;n<8;n++){
      const res=await callAI();
      AI.msgs.push({role:'assistant',content:res.content});
      res.content.filter(b=>b.type==='text'&&b.text.trim()).forEach(b=>AI.log.push({k:'ai',t:b.text.trim()}));
      const uses=res.content.filter(b=>b.type==='tool_use');
      if(!uses.length)break;
      const results=uses.map(u=>{const l=[];let out;try{out=applyTool(u.name,u.input,l);if(u.name!=='get_site_data')changed=true;}catch(e){out={error:e.message};}l.forEach(x=>AI.log.push({k:'act',t:x}));return {type:'tool_result',tool_use_id:u.id,content:JSON.stringify(out).slice(0,12000)};});
      AI.msgs.push({role:'user',content:results});redraw();
    }
  }catch(e){AI.log.push({k:'err',t:e.message});}
  if(changed){AI.snaps.push(snap);commit();AI.log.push({k:'act',t:'These edits are drafts. Review them, then press Publish.'});buildSide();}
  AI.busy=false;redraw();
}
function pageAssistant(){
  const wrap=H('div',{},H('h1',{class:'h1'},'Ask Claude'),H('p',{class:'lead'},'Tell Claude what to change, for example "add my new Google certificate to Additional certificates" or "rewrite my about text". Claude edits a draft; nothing goes live until you press Publish.'));
  const log=H('div',{class:'log'}),ta=H('textarea',{rows:1,placeholder:'Ask Claude to edit your site or help you write...'});
  const redraw=()=>{log.innerHTML='';
    if(!AI.log.length)log.append(H('div',{class:'bub ai'},'Hi! I can add, change, move or delete projects, internships, certificates, badges and text on your site, and help with writing. What would you like to do?'));
    AI.log.forEach(m=>log.append(H('div',{class:'bub '+(m.k==='me'?'me':m.k==='act'?'act':'ai'),style:m.k==='err'?'border-color:#6a2d3a;color:#ffb3b3':''},m.t)));
    if(AI.busy)log.append(H('div',{class:'bub ai'},'Working...'));
    log.scrollTop=log.scrollHeight;send.disabled=AI.busy;undo.disabled=!AI.snaps.length||AI.busy;};
  const send=H('button',{class:'btn pri',type:'submit'},'Send'),undo=H('button',{class:'btn',type:'button',onclick:()=>{const s=AI.snaps.pop();if(!s)return;S=s;commit();buildSide();AI.log.push({k:'act',t:'Undid the last Claude edit.'});redraw();}},'Undo last edit');
  const form=H('form',{onsubmit:e=>{e.preventDefault();const t=ta.value.trim();if(!t||AI.busy)return;ta.value='';runAI(t,redraw);}},ta,send,undo);
  ta.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
  const chips=H('div',{class:'chips'},['Add a new certificate to Additional certificates','Rewrite my about text to sound more professional','Which certificates are best for a BBA student?','Suggest a stronger tagline'].map(q=>H('button',{type:'button',onclick:()=>{ta.value=q;ta.focus();}},q)));
  wrap.append(H('div',{class:'card chat'},log,chips,form));redraw();
  if(AI.pending){const t=AI.pending;AI.pending='';runAI(t,redraw);}
  return wrap;
}


/* ---------- Dashboard home ---------- */
function pageDashboard(){
  const main=S.certs.filter(c=>c.group!=='additional').length,add=S.certs.length-main,dirty=isDirty(),cfg=ghCfg();
  const wrap=H('div',{},H('h1',{class:'h1'},'Portfolio dashboard'),H('p',{class:'lead'},'Welcome back'+(S.hero.first?', '+cap(S.hero.first):'')+'. Change anything from here, then press Publish.'));
  const g=H('div',{class:'grid'});
  const stat=(n,l,r)=>H('a',{class:'stat',href:'#/'+r,style:'text-decoration:none'},H('b',{},String(n)),H('span',{},l));
  g.append(card('Your portfolio at a glance',
    H('div',{class:'stats'},stat(S.projects.length,'Projects','projects'),stat(S.internships.length,'Internships','interns'),stat(main+' + '+add,'Certificates + additional','certs'),stat(S.badges.length,'Digital badges','badges')),
    H('p',{class:'note'},dirty?'You have changes that are not published yet.':'Everything you see here is published.'),
    H('div',{class:'row'},H('button',{class:'btn pri',onclick:doPublish},icon('up2'),'Publish'),H('a',{class:'btn',href:'../index.html',target:'_blank',rel:'noopener'},icon('eye'),'Preview site'))));
  const vis=H('div',{class:'muted'},'Loading...');
  g.append(H('section',{class:'card'},H('h3',{},'Visitors',H('small',{},'last 28 days')),vis,H('div',{class:'row',style:'margin-top:12px'},H('a',{class:'btn sm',href:'#/visitors'},'Open visitors'))));
  loadStats().then(d=>{
    const keys=[];for(let i=27;i>=0;i--)keys.push(new Date(Date.now()-i*864e5).toISOString().slice(0,10));
    const n=keys.reduce((a,k)=>a+((d.days||{})[k]||0),0);vis.className='';vis.innerHTML='';
    vis.append(H('div',{class:'big'},String(n)),H('div',{class:'muted',style:'margin-bottom:10px'},'views, '+(d.total||0)+' all time'),
      ...(d.countries||[]).slice(0,3).map(c=>H('div',{class:'li',style:'margin:6px 0'},H('span',{},flag(c.code)),H('b',{style:'font-weight:500'},c.name||c.code),H('b',{style:'margin-left:auto'},String(c.count)))));
  }).catch(e=>{vis.className='';vis.innerHTML='';vis.append(statsProblem(e));});
  const prompt=H('textarea',{rows:3,placeholder:'e.g. Add my new Google certificate to Additional certificates'});
  g.append(card('Ask Claude',H('p',{class:'note'},'Claude can edit your draft for you: add certificates, rewrite text, reorder things.'),H('div',{class:'fld'},prompt),H('button',{class:'btn pri',onclick:()=>{if(prompt.value.trim())AI.pending=prompt.value.trim();go('assistant');}},icon('spark'),'Ask')));
  g.append(card('Recently added',H('div',{class:'list'},S.certs.slice(-4).reverse().map(c=>titleCell(c.file,c.title,[c.issuer,c.date].filter(Boolean).join(' · '))))));
  const chk=(ok,t,r)=>H('div',{class:'li'},H('span',{class:ok?'ok':'muted'},ok?'✓':'○'),H('span',{},t),r?H('a',{class:'btn sm',style:'margin-left:auto',href:'#/'+r},'Open'):null);
  g.append(card('Setup checklist',H('div',{class:'list'},
    chk(!!(cfg.owner&&cfg.repo&&cfg.token),'GitHub publishing connected','settings'),
    chk(!!adminTok(),'Admin token set (Visitors and Claude)','settings'),
    chk(!!S.profile.photo,'Profile picture added','profile'),
    chk(S.badges.length>0,'Digital badge added','badges'),
    chk(!isDirty(),'Nothing waiting to be published',''))));
  wrap.append(g);return wrap;
}

/* ---------- Settings ---------- */
function pageSettings(){
  const cfg=ghCfg(),wrap=H('div',{},H('h1',{class:'h1'},'Settings'),H('p',{class:'lead'},'Connections are saved only in this browser. They are never written into your site files.'));
  const g=H('div',{class:'grid two'});
  const saveCfg=()=>LS.set('sk-gh',cfg);
  const msg=H('p',{class:'note'},'');
  g.append(card('Publish to GitHub',
    H('p',{class:'note'},'Create a fine-grained personal access token on GitHub with "Contents: Read and write" for your portfolio repository only.'),
    field(cfg,{key:'owner',label:'GitHub user or organisation',ph:'your-username'},saveCfg),field(cfg,{key:'repo',label:'Repository name',ph:'portfolio'},saveCfg),field(cfg,{key:'branch',label:'Branch',ph:'main'},saveCfg),field(cfg,{key:'token',label:'Access token',type:'password',ph:'github_pat_...'},saveCfg),
    H('div',{class:'row'},H('button',{class:'btn',onclick:async()=>{msg.className='note';msg.textContent='Checking...';try{const r=await gh(cfg,'');const b=await gh(cfg,'/branches/'+encodeURIComponent(cfg.branch||'main'));msg.className='note ok';msg.textContent='Connected to '+r.full_name+' (branch '+b.name+').';}catch(e){msg.className='note bad';msg.textContent=e.message;}}},'Test connection'),H('button',{class:'btn pri',onclick:doPublish},'Publish now'),H('button',{class:'btn',onclick:downloadDataFile},'Download data file')),msg));
  const tokBox={t:adminTok()},tmsg=H('p',{class:'note'},'');
  g.append(card('Admin token (Visitors and Claude)',
    H('p',{class:'note'},'Set the same secret as ADMIN_TOKEN in your Netlify environment variables. Without it, the visitor map and the Claude assistant stay off.'),
    field(tokBox,{key:'t',label:'Admin token',type:'password'},()=>LS.set('sk-admintoken',tokBox.t)),
    H('button',{class:'btn',onclick:async()=>{tmsg.className='note';tmsg.textContent='Checking...';try{ADM.stats=null;await loadStats(true);tmsg.className='note ok';tmsg.textContent='Token accepted. Visitor tracking is reachable.';}catch(e){tmsg.className='note bad';tmsg.textContent={notoken:'Enter a token first.',badtoken:'The server rejected that token.',nofn:'The Netlify functions were not found. Deploy on Netlify first (see README).'}[e.code]||e.message;}}},'Test token'),tmsg));
  const ch=()=>commit();
  g.append(card('Site intro',field(S.settings,{key:'introEnabled',label:'Play the sunset intro animation when the site opens',type:'check'},ch),
    H('p',{class:'note'},'Pictures shown on the four boxes at the end of the intro (leave empty to use the automatic one).'),
    field(S.intro,{key:'projects',label:'Projects box picture',type:'file',max:600},ch),field(S.intro,{key:'internships',label:'Internships box logo',type:'file',max:600},ch),field(S.intro,{key:'certs',label:'Certificates box picture',type:'file',max:600},ch),field(S.intro,{key:'skills',label:'Skills box picture',type:'file',max:600},ch)));
  const pw={user:'Shashaank Kumar Sinha',cur:'',n1:'',n2:''},pm=H('p',{class:'note'},'');
  g.append(card('Studio login',
    H('p',{class:'note'},'This sign-in only hides the editor from casual visitors, because the site is static. What really protects your site is that only your GitHub token can publish. Choose a long, unique password.'),
    field(pw,{key:'user',label:'User name'}),field(pw,{key:'cur',label:'Current password',type:'password'}),field(pw,{key:'n1',label:'New password (min 10 characters)',type:'password'}),field(pw,{key:'n2',label:'Repeat new password',type:'password'}),
    H('button',{class:'btn',onclick:()=>{
      pm.className='note bad';
      if(!checkLogin(pw.user,pw.cur)){pm.textContent='Current user name or password is not right.';return;}
      if(pw.n1.length<10||pw.n1!==pw.n2){pm.textContent='The new passwords must match and be at least 10 characters.';return;}
      const salt='sk-'+Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b=>b.toString(16).padStart(2,'0')).join('');
      S.settings.adminSalt=salt;S.settings.adminIter=3000;S.settings.adminHash=loginHash(pw.user,pw.n1,{adminSalt:salt,adminIter:3000});
      commit();pw.cur=pw.n1=pw.n2='';pm.className='note ok';pm.textContent='Changed. Press Publish so the live Studio page uses the new password.';
    }},'Change password'),pm));
  const imp=H('input',{type:'file',accept:'.json,application/json',hidden:true});
  imp.onchange=async()=>{const f=imp.files[0];if(!f)return;try{const j=JSON.parse(await f.text());if(!j.profile||!j.hero)throw new Error('That does not look like a portfolio backup.');S=normalize(j);commit();buildSide();renderRoute();toast('Backup imported');}catch(e){toast(e.message);}imp.value='';};
  g.append(card('Backup and reset',
    H('p',{class:'note'},'A backup includes everything, including images you uploaded and have not published yet.'),
    H('div',{class:'row'},H('button',{class:'btn',onclick:()=>{downloadText('portfolio-backup-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify(S),'application/json');}},'Download backup'),H('button',{class:'btn',onclick:()=>imp.click()},'Import backup'),imp),
    H('div',{style:'margin-top:14px'},H('button',{class:'btn danger',onclick:async()=>{if(!confirm('Throw away all unpublished changes in this browser and go back to the published version?'))return;await DB.del('draft');HAS_DRAFT=false;S=clone(PUB);buildSide();updateStatus();renderRoute();toast('Draft discarded');}},'Discard unpublished changes'))));
  wrap.append(g);return wrap;
}

const PAGES={dashboard:pageDashboard,profile:pageProfile,projects:projectsPage,interns:internsPage,certs:certsPage,badges:badgesPage,content:contentPage,visitors:pageVisitors,assistant:pageAssistant,settings:pageSettings};

/* ---------- start ---------- */
async function boot(){
  const draft=await DB.get('draft');
  if(draft&&draft.data&&String(draft.data.updated||'')>String(BASE.updated||'')){S=normalize(draft.data);HAS_DRAFT=true;}
  window.addEventListener('hashchange',()=>{if(!$('#studio').hidden){closeDrawer();renderRoute();}});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDrawer();if(!$('#dlg').dataset.lock)closeDlg();}});
  if(sessionOk())enterStudio();else{$('#login').hidden=false;startLogin();}
}
window.__studio={get S(){return S;},commit,applyTool,buildPublish};
boot();
})();
