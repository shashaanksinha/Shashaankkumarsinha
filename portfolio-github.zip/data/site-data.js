/* Edited by the Studio dashboard. You can also edit it by hand. */
window.SITE_DATA = {
 "schema": 2,
 "updated": "2026-10-24T05:34:13Z",
 "profile": {
  "name": "Shashaank Kumar Sinha",
  "photo": "assets/profile/profile.jpg"
 },
 "hero": {
  "line1": "hi, i'm",
  "first": "shashaank",
  "last": "kumar sinha",
  "tagline": "a bba & ai student driven by analytical thinking and real projects"
 },
 "about": {
  "text": "I'm a first-year BBA student with international schooling across the UAE and India. I focus on database systems, business analytics, and applied AI, and I enjoy turning business problems into things I can actually build and show. Let's build something worth measuring together."
 },
 "headings": {
  "about": "About me",
  "skills": "What I Do",
  "projects": "Project",
  "internships": "Internships",
  "certs": "Certificates",
  "linkedin": "On LinkedIn",
  "contact": "Let's Talk",
  "certsMore": "Additional Certificates",
  "badges": "Digital Badges"
 },
 "marquee1": [
  "Database Systems",
  "Tableau",
  "MS Excel",
  "AI Tools",
  "Business Analytics",
  "E-commerce"
 ],
 "marquee2": [
  "Public Speaking",
  "Teamwork",
  "Cross-Cultural Comms",
  "Entrepreneurial Mindset",
  "Adaptability"
 ],
 "skills": [
  {
   "title": "Database & Business Systems",
   "text": "Designing relational database systems for inventory and employee-leave management, from schema to working tool."
  },
  {
   "title": "Data Analytics",
   "text": "Building dashboards in Tableau and classifying data in Excel to draw clear business conclusions."
  },
  {
   "title": "Applied AI Tools",
   "text": "Trained in using AI tools and methodologies to support practical workflows and strategic planning."
  },
  {
   "title": "Cross-Cultural Teamwork",
   "text": "Collaborated within an international team in the UAE to build and ship a project under time pressure."
  },
  {
   "title": "Pitching & Public Speaking",
   "text": "Presented a completed technical solution to a panel of reviewers at a regional hackathon."
  }
 ],
 "projects": [
  {
   "label": "Marketing & Brand Management · Sem 1 · 2026",
   "title": "F1 Netflix Effect",
   "pill": "Live project",
   "text": "How the Drive to Survive docuseries changed Formula 1's brand image, US audience and sponsorships, studied with a relational database, an Excel dashboard and an AI-assisted workflow.",
   "details": "F1 Netflix Effect is a Sem 1 Marketing & Brand Management live project on how the Drive to Survive docuseries changed Formula 1's brand image, US audience and sponsorships. It uses an OpenOffice Base database, an Excel dashboard with six charts and a year selector, and an AI log of AI-assisted steps. In the dashboard, average US viewers per race rose from about 546,000 (2017-18) to about 991,000 (2019-25), roughly +81.5%; the fan survey shows female share rising from 10% to 18.3% and average age falling from 36 to 32. The sponsor-deal log is a starter list. The workbook has these sheets: SEASON, VIEWERSHIP, AUDIENCE, SOCIAL, SPONSOR, DEAL, Analysis, Sources, AI_Log, Calc and Dashboard. Viewership data comes from ESPN Press Room and fan data from the F1 Global Fan Survey.",
   "link": "",
   "image": ""
  },
  {
   "label": "Academic Project · 2025",
   "title": "DBMS Employee Leave Management",
   "pill": "Coursework",
   "text": "Relational database system to automate, track, and manage employee leave requests and balances efficiently.",
   "details": "",
   "link": "",
   "image": ""
  },
  {
   "label": "Hackathon · 2023",
   "title": "UAE Regional Hackathon",
   "pill": "Team of 3",
   "text": "Built a project from scratch with a 3-member UAE-based team, then pitched the finished solution to a panel of reviewers.",
   "details": "",
   "link": "",
   "image": ""
  },
  {
   "label": "Academic Project · 2023",
   "title": "DBMS Inventory Management",
   "pill": "Coursework",
   "text": "Functional inventory management system using core database concepts to track and manage stock data efficiently.",
   "details": "",
   "link": "",
   "image": ""
  }
 ],
 "internships": [
  {
   "title": "Virtual Advanced Excel Reporting & Analytics Trainee",
   "org": "YuvaIntern · Bhubaneswar · Remote",
   "start": "21 Sep 2026",
   "end": "19 Oct 2026",
   "dur": "4 weeks",
   "weeks": [
    "Strategic Planning for Advanced Excel Reporting",
    "Data Sourcing, Cleaning, and Documentation",
    "Advanced Excel Dashboard Design and Analysis Techniques",
    "Analytical Reporting Evaluation and Presentation Preparation"
   ],
   "offerFile": "assets/internships/virtual-advanced-excel-reporting-analytics-trainee-offer-letter.pdf",
   "offerLabel": "Virtual Advanced Excel Reporting and Analytics Trainee at YuvaIntern Offer Letter"
  },
  {
   "title": "Junior AI Business Strategy Intern",
   "org": "YuvaIntern · Remote",
   "start": "13 Oct 2026",
   "end": "17 Nov 2026",
   "dur": "5 weeks",
   "weeks": [
    "AI Market Opportunity Analysis",
    "Strategic AI Roadmap Development",
    "AI-Driven Business Innovation Proposal",
    "AI Strategy Performance Metrics and KPI Design",
    "AI Implementation Planning and Risk Assessment"
   ],
   "offerFile": "assets/internships/junior-ai-business-strategy-intern-offer-letter.pdf",
   "offerLabel": "Junior AI Business Strategy Intern at YuvaIntern Offer Letter"
  }
 ],
 "certs": [
  {
   "title": "AI Fluency: Framework & Foundations",
   "issuer": "Anthropic",
   "date": "Sep 2026",
   "id": "",
   "desc": "Foundational framework for working with AI effectively and responsibly.",
   "file": "assets/certs/anthropic-ai-fluency.pdf",
   "link": "https://verify.skilljar.com/c/x3qva6pqdvp9",
   "group": "main"
  },
  {
   "title": "Deloitte Australia – Data Analytics Job Simulation",
   "issuer": "Forage",
   "date": "Jun 2026",
   "id": "RGbghTYvzMpmx5TGc",
   "desc": "Forage job simulation with practical tasks in data analysis and forensic technology, including a Tableau dashboard.",
   "file": "assets/certs/forage-deloitte-data-analytics.webp",
   "link": "https://www.theforage.com/completion-certificates/9PBTqmSxAf6zZTseP/io9DzWKe3PTsiS6GG_9PBTqmSxAf6zZTseP_6a438e2cdea7e0a1a5933ad1_1782840710947_completion_certificate.pdf",
   "group": "main"
  },
  {
   "title": "EY – Technology Risk Job Simulation",
   "issuer": "Forage",
   "date": "Jul 2026",
   "id": "Nx8L4rJs7bigLEhtj",
   "desc": "Forage job simulation on typical IT risks and processes for EY's Technology Risk team.",
   "file": "",
   "link": "https://www.theforage.com/completion-certificates/Z3pPDqCPapFTSGBgi/25RAqjzJnD3b8YPZv_Z3pPDqCPapFTSGBgi_6a438e2cdea7e0a1a5933ad1_1782913639323_completion_certificate.pdf",
   "group": "main"
  },
  {
   "title": "Basics of Business Analytics",
   "issuer": "UniAthena (with Cambridge International Qualifications)",
   "date": "Sep 2026",
   "id": "8034-2430-3407",
   "desc": "Introductory business analytics course developed by UniAthena with Cambridge International Qualifications, blockchain-verified.",
   "file": "assets/certs/uniathena-business-analytics.webp",
   "link": "https://uniathena.com/verify/certificate?certID=8034-2430-3407",
   "group": "main"
  },
  {
   "title": "Strategic Planning in the AI Age",
   "issuer": "HP LIFE",
   "date": "Sep 2026",
   "id": "16caf20a-672a-4af6-abce-36c5d1d192d4",
   "desc": "HP LIFE online course on strategic planning in the age of AI.",
   "file": "",
   "link": "https://www.life-global.org/certificate/16caf20a-672a-4af6-abce-36c5d1d192d4",
   "group": "main"
  },
  {
   "title": "AI for Business Professionals",
   "issuer": "HP LIFE",
   "date": "Sep 2026",
   "id": "",
   "desc": "HP LIFE course on AI's role in business, effective prompts and ethical use.",
   "file": "assets/certs/hp-life-ai-for-business-professionals.pdf",
   "link": "",
   "group": "main"
  },
  {
   "title": "Certificate in Advanced Excel",
   "issuer": "Amity University Online",
   "date": "Aug 2026",
   "id": "H2bsNw5CUh",
   "desc": "Amity University Online certificate of accomplishment in Advanced Excel.",
   "file": "assets/certs/amity-advanced-excel.webp",
   "link": "https://amigo.amityonline.com/mod/customcert/verify_certificate.php?code=H2bsNw5CUh&qrcode=1",
   "group": "main"
  },
  {
   "title": "Data Analysis with Python",
   "issuer": "Cognitive Class (IBM)",
   "date": "Sep 2026",
   "id": "14db29b1399e4365826d2a8b35f49434",
   "desc": "IBM-provided course (DA0101EN) on analysing data with Python, completed with a passing grade.",
   "file": "assets/certs/cognitive-class-data-analysis-python.webp",
   "link": "https://courses.cognitiveclass.ai/certificates/14db29b1399e4365826d2a8b35f49434",
   "group": "main"
  },
  {
   "title": "One Million Prompters",
   "issuer": "Dubai Future Foundation",
   "date": "Sep 2026",
   "id": "",
   "desc": "Dubai initiative focused on prompt engineering skills for AI systems.",
   "file": "assets/certs/one-million-prompters.webp",
   "link": "https://omp.dub.ai/certificate/36UPFOn49DmP",
   "group": "main"
  },
  {
   "title": "Financial & Non Financial Corporate Reporting",
   "issuer": "Metropolitan School of Business and Management UK",
   "date": "Oct 2026",
   "id": "20155709",
   "desc": "Free online CPD-certified course on corporate reporting from the Metropolitan School of Business and Management UK.",
   "file": "assets/certs/metropolitan-corporate-reporting.webp",
   "link": "",
   "group": "main"
  },
  {
   "title": "AI in Finance",
   "issuer": "Simplilearn",
   "date": "Oct 2026",
   "id": "10820816",
   "desc": "Simplilearn SkillUP online course on applying AI in finance.",
   "file": "assets/certs/simplilearn-ai-in-finance.webp",
   "link": "",
   "group": "main"
  },
  {
   "title": "Introduction to Generative AI",
   "issuer": "Simplilearn (Google Cloud)",
   "date": "Sep 2026",
   "id": "10689321",
   "desc": "Introductory generative AI course from Simplilearn SkillUP, powered by Google Cloud.",
   "file": "assets/certs/simplilearn-intro-generative-ai.webp",
   "link": "https://www.simplilearn.com/skillup-certificate-landing?token=eyJjb3Vyc2VfaWQiOiIzODA3IiwiY2VydGlmaWNhdGVfdXJsIjoiaHR0cHM6XC9cL2NlcnRpZmljYXRlcy5zaW1wbGljZG4ubmV0XC9zaGFyZVwvMTA2ODkzMjFfMTEwMjAwNTlfMTc4ODQ1NzI0NzM0OC5wbmciLCJ1c2VybmFtZSI6IlNoYXNoYWFuayBLdW1hciBTaW5oYSJ9&utm_source=shared-certificate&utm_medium=lms&utm_campaign=shared-certificate-promotion&referrer=https%3A%2F%2Flms.simplilearn.com%2Fcourses%2F6750%2FIntroduction-to-Generative-AI%2Fcertificate%2Fdownload-skillup&%24web_only=true&_branch_match_id=1624319016160380191&_branch_referrer=H4sIAAAAAAAAA8soKSkottLXL87MLcjJ1EssKNDLyczL1k%2FVNwo38vS29HS2ME2yrytKTUstKsrMS49PKsovL04tsvXJzMtOTfHMAwDmhbyYQQAAAA%3D%3D",
   "group": "main"
  },
  {
   "title": "Government Accelerators",
   "issuer": "Mohammed Bin Rashid Centre for Government Innovation (Ibtekr)",
   "date": "Oct 2026",
   "id": "",
   "desc": "Online course on government innovation from the Mohammed Bin Rashid Centre for Government Innovation, delivered on the Ibtekr platform.",
   "file": "assets/certs/government-accelerators-ibtekr.webp",
   "link": "",
   "group": "additional"
  },
  {
   "title": "Graphic Design Essentials",
   "issuer": "Canva",
   "date": "Sep 2026",
   "id": "ce2933",
   "desc": "Core graphic design skills, completed through Canva Design School.",
   "file": "",
   "link": "https://www.canva.com/design-school/certification-award/ce293390-22f1-42f6-9de8-beb79fba42fe?examCompleted=true&earnedBadges=learning-certificate-1",
   "group": "additional"
  },
  {
   "title": "Future Ready with AI Tools",
   "issuer": "Amity University Online",
   "date": "Aug 2026",
   "id": "M4ZsK2eLQf",
   "desc": "3-day Student Development Program on using AI tools, held 29-31 July 2026 by Amity University Online.",
   "file": "assets/certs/amity-future-ready-ai-tools.webp",
   "link": "https://amigo.amityonline.com/mod/customcert/verify_certificate.php?code=M4ZsK2eLQf&qrcode=1",
   "group": "additional"
  },
  {
   "title": "Advanced Certificate in Career Readiness",
   "issuer": "Amity University Online",
   "date": "Jul 2026",
   "id": "A0lbApDAzH",
   "desc": "Webinar series for career enhancement, held 3 June to 10 July 2026 by Amity University Online.",
   "file": "assets/certs/amity-career-readiness.webp",
   "link": "",
   "group": "additional"
  },
  {
   "title": "Code Battle '23 – Sharjah & N. Emirates",
   "issuer": "iCodejr.com",
   "date": "Oct 2023",
   "id": "7643-2388-2381-0120",
   "desc": "Coding competition assessing coding, creativity, UI, teamwork and presentation skills.",
   "file": "assets/certs/code-battle-23.webp",
   "link": "https://app.certif-id.com/certificate-view/a8fb32dda51abdabc315705552767728dabfe8b4d7a221b2f92579739b593e0f",
   "group": "additional"
  },
  {
   "title": "Financial Literacy Programme",
   "issuer": "Deloitte WorldClass",
   "date": "Sep 2026",
   "id": "",
   "desc": "Deloitte WorldClass course on financial literacy.",
   "file": "assets/certs/deloitte-financial-literacy.webp",
   "link": "",
   "group": "additional"
  },
  {
   "title": "SkillQuest – Generative AI Literacy",
   "issuer": "Simplilearn",
   "date": "Sep 2026",
   "id": "11979830",
   "desc": "Simplilearn assessment on generative AI literacy, passed.",
   "file": "assets/certs/simplilearn-skillquest-genai-literacy.webp",
   "link": "",
   "group": "additional"
  },
  {
   "title": "Gemini Certified Student · K12",
   "issuer": "Google for Education",
   "date": "Sep 2026",
   "id": "",
   "desc": "Google for Education qualification for using Google AI in education, valid through 09/25/2029.",
   "file": "assets/certs/google-gemini-k12.webp",
   "link": "https://edu.exceedlms.com/student/award/xhX28HeR6QGP2Cb9BkQNWRWm",
   "group": "additional"
  },
  {
   "title": "AI Skills Passport",
   "issuer": "EY and Microsoft",
   "date": "",
   "id": "",
   "desc": "EY and Microsoft course covering general and employability AI skills.",
   "file": "assets/certs/ey-microsoft-ai-skills-passport.webp",
   "link": "",
   "group": "additional"
  },
  {
   "title": "Generative AI Mastermind",
   "issuer": "Outskill",
   "date": "Mar 2025",
   "id": "",
   "desc": "Outskill course on generative AI.",
   "file": "assets/certs/outskill-generative-ai-mastermind.webp",
   "link": "",
   "group": "additional"
  }
 ],
 "extras": [],
 "linkedin": [
  {
   "url": "https://www.linkedin.com/embed/feed/update/urn:li:share:7515385758019538944?collapsed=1",
   "height": "608"
  },
  {
   "url": "https://www.linkedin.com/embed/feed/update/urn:li:share:7515113550382653440?collapsed=1",
   "height": "640"
  }
 ],
 "contact": {
  "email": "shashaankkumarsinha@rediffmail.com",
  "phone": "+91 91473 80629",
  "location": "Jamshedpur, India",
  "footer": "© 2026 Shashaank Kumar Sinha, Jamshedpur, India"
 },
 "chat": {
  "kb": [
   {
    "k": "who about introduce yourself background summary student name profile person bio describe",
    "a": "Shashaank Kumar Sinha is a first-year BBA student at Amity University Online (Delhi NCR, expected graduation 2029) with schooling in the UAE and India. Interests: database systems, business analytics and applied AI. Based in Jamshedpur, Jharkhand, India.",
    "m": "Strengths listed on the CV: analytical thinking, entrepreneurial mindset, cross-cultural communication, teamwork, public speaking and adaptability. Hands-on work: two remote internships, four projects and 22 certificates."
   },
   {
    "k": "education school college university degree bba cbse 10th 12th ssc hsc study studying qualification amity woodlem melior ajman commerce academic graduation",
    "a": "Education: BBA at Amity University Online, Delhi NCR (expected 2029); 12th Commerce (CBSE) at South Melior School, West Bengal (2026); 10th (CBSE) at Woodlem Park School, Ajman, UAE (2024).",
    "m": "Amity University Online certificates on the portfolio: Future Ready with A.I (Jul 2026) and Certificate in Advanced Excel."
   },
   {
    "k": "skills skill tools technical software excel tableau dbms office powerpoint word abilities competencies expertise good at",
    "a": "Technical skills: MS Office (Word, Excel, PowerPoint), database concepts (DBMS), internet research, AI tools and applications, e-commerce and Tableau. Soft skills: entrepreneurial mindset, cross-cultural communication, teamwork, public speaking, adaptability and punctuality.",
    "m": "Proof points: Tableau dashboard and Excel analysis (Deloitte job simulation), Excel reporting internship, Advanced Excel certificate, database projects (inventory and employee leave) and AI certificates."
   },
   {
    "k": "language languages speak spoken english hindi fluent communicate",
    "a": "Languages listed on the CV: English and Hindi.",
    "m": ""
   },
   {
    "k": "ai artificial intelligence prompt prompting generative genai chatgpt gemini llm",
    "a": "AI is a core interest: Anthropic's AI Fluency, One Million Prompters (Dubai Future Foundation), Introduction to Generative AI (Simplilearn), HP LIFE AI courses, Google's Gemini Certified Student, Future Ready with A.I (Amity) and a Junior AI Business Strategy internship.",
    "m": ""
   },
   {
    "k": "linkedin post posts social profile network",
    "a": "Two LinkedIn posts are embedded in the 'On LinkedIn' section of this site. Search for Shashaank Kumar Sinha on LinkedIn to find the profile.",
    "m": ""
   },
   {
    "k": "best favourite favorite top proudest strongest highlight standout important impressive recent latest",
    "a": "Shashaank hasn't ranked anything, but the most recent and detailed work is the F1 Netflix Effect project: a database, a six-chart Excel dashboard and a video walkthrough (use 'Show me' under the project).",
    "m": ""
   },
   {
    "k": "strength strengths why hire hiring fit good suitable recommend value offer bring unique",
    "a": "From the CV: analytical thinking, database design, Tableau and Excel dashboards, applied AI, teamwork across countries and public speaking, backed by two internships, four projects and 22 certificates. For a fit conversation, email shashaankkumarsinha@rediffmail.com.",
    "m": ""
   },
   {
    "k": "weakness weaknesses flaw drawback improve improvement negative",
    "a": "Self-assessments like that aren't part of the portfolio, so I won't guess. For a direct conversation, email shashaankkumarsinha@rediffmail.com.",
    "m": ""
   },
   {
    "k": "hobby hobbies interest interests free time passion fun sport music movie",
    "a": "Hobbies aren't listed on the CV or portfolio. The interests shown are database systems, business analytics and applied AI.",
    "m": ""
   }
  ],
  "facts": [
   {
    "k": "student bba amity university pursuing study studying undergraduate degree online",
    "s": "Shashaank is a first-year BBA student at Amity University Online (expected graduation 2029).",
    "v": ""
   },
   {
    "k": "commerce cbse 12th hsc south melior west bengal school",
    "s": "Shashaank completed 12th (Commerce, CBSE) at South Melior School, West Bengal in 2026.",
    "v": ""
   },
   {
    "k": "10th ssc woodlem ajman school",
    "s": "Shashaank completed 10th (CBSE) at Woodlem Park School, Ajman, UAE in 2024.",
    "v": ""
   },
   {
    "k": "uae dubai ajman emirates abroad international overseas sharjah gulf",
    "s": "Shashaank went to school in the UAE (Woodlem Park School, Ajman, 10th in 2024), joined a UAE regional hackathon in 2023 and earned Dubai Future Foundation and Code Battle '23 (Sharjah & N. Emirates) certificates.",
    "v": ""
   },
   {
    "k": "india indian jamshedpur jharkhand delhi location based live lives city",
    "s": "Shashaank is based in Jamshedpur, Jharkhand, India, and studies with Amity University Online (Delhi NCR).",
    "v": ""
   },
   {
    "k": "english hindi language fluent speak",
    "s": "English and Hindi are the languages listed on the CV.",
    "v": ""
   },
   {
    "k": "excel spreadsheet pivot formula office microsoft",
    "s": "Excel is on the skills list, and the evidence includes a Certificate in Advanced Excel (Amity University Online), an Advanced Excel Reporting & Analytics internship, and Excel data classification in the Deloitte simulation.",
    "v": ""
   },
   {
    "k": "word powerpoint office microsoft ms",
    "s": "MS Office (Word, Excel, PowerPoint) is listed under technical skills.",
    "v": ""
   },
   {
    "k": "tableau dashboard visualization visualisation bi analytics",
    "s": "Tableau is on the skills list, and Shashaank built a Tableau data dashboard in the Deloitte Australia Data Analytics job simulation (Forage, Jun 2026).",
    "v": ""
   },
   {
    "k": "data analysis analytics analyst analysing analyzing",
    "s": "Data analysis shows up in the Deloitte Data Analytics simulation, the Basics of Business Analytics (UniAthena) certificate, Data Analysis with Python (Cognitive Class) and the F1 Netflix Effect project.",
    "v": ""
   },
   {
    "k": "python",
    "s": "Python isn't listed as a skill on the CV, but Shashaank holds a Data Analysis with Python certificate (Cognitive Class, Sep 2026).",
    "v": "partly"
   },
   {
    "k": "programming programmer coding coder code developer software java javascript",
    "s": "Programming languages aren't listed as skills on the CV. The closest evidence is the Data Analysis with Python certificate, the Code Battle '23 certificate and database projects.",
    "v": "partly"
   },
   {
    "k": "dbms database databases relational schema",
    "s": "Database design is a core skill: Shashaank built a DBMS Inventory Management project (2023) and a DBMS Employee Leave Management project (2025), and used an OpenOffice Base database in the F1 project.",
    "v": ""
   },
   {
    "k": "sql oracle mysql query queries",
    "s": "SQL isn't named on the CV, though Shashaank built relational database projects (inventory and employee leave management).",
    "v": "partly"
   },
   {
    "k": "ai artificial intelligence generative genai prompt prompting tools",
    "s": "AI is a major focus: Anthropic AI Fluency, One Million Prompters, Introduction to Generative AI, HP LIFE AI courses, Gemini Certified Student, Future Ready with A.I and a Junior AI Business Strategy internship.",
    "v": ""
   },
   {
    "k": "anthropic claude fluency",
    "s": "Shashaank completed AI Fluency: Framework & Foundations from Anthropic (Sep 2026).",
    "v": ""
   },
   {
    "k": "google gemini k12 education",
    "s": "Shashaank is a Gemini Certified Student (K12) from Google for Education (issued Sep 2026).",
    "v": ""
   },
   {
    "k": "canva graphic design designing poster",
    "s": "Shashaank earned the Graphic Design Essentials certificate from Canva (Sep 2026).",
    "v": ""
   },
   {
    "k": "finance financial accounting reporting corporate",
    "s": "Finance-related certificates: Financial Literacy Programme (Deloitte), Financial & Non Financial Corporate Reporting (Metropolitan) and AI in Finance.",
    "v": ""
   },
   {
    "k": "ecommerce commerce online business entrepreneur entrepreneurial entrepreneurship startup",
    "s": "E-commerce and an entrepreneurial mindset are both listed in the skills section of the CV.",
    "v": ""
   },
   {
    "k": "leadership lead leader management manage",
    "s": "The CV summary mentions analytical thinking and leadership, and lists teamwork, public speaking and an entrepreneurial mindset as soft skills.",
    "v": ""
   },
   {
    "k": "team teamwork collaboration collaborate",
    "s": "Teamwork is a listed skill, shown by the 3-member UAE hackathon team and the Forage simulations.",
    "v": ""
   },
   {
    "k": "public speaking presentation pitch present communicate communication",
    "s": "Public speaking is a listed skill: Shashaank pitched a completed solution to a panel of reviewers at the 2023 UAE Regional Hackathon.",
    "v": ""
   },
   {
    "k": "hackathon uae regional competition contest pitched pitch",
    "s": "Shashaank took part in the UAE Regional Hackathon (2023) in a 3-member team and pitched the finished solution to a panel.",
    "v": ""
   },
   {
    "k": "code battle icodejr sharjah competition contest coding",
    "s": "Shashaank has a Code Battle '23 (Sharjah & N. Emirates) certificate from iCodejr.com (Oct 2023).",
    "v": ""
   },
   {
    "k": "intern internship yuvaintern remote trainee experience",
    "s": "Shashaank has done two remote internships with YuvaIntern: Virtual Advanced Excel Reporting & Analytics Trainee (21 Sep-19 Oct 2026) and Junior AI Business Strategy Intern (13 Oct-17 Nov 2026).",
    "v": ""
   },
   {
    "k": "forage simulation virtual job deloitte ey",
    "s": "Shashaank completed two Forage job simulations: Deloitte Australia Data Analytics (Jun 2026) and EY Technology Risk (Jul 2026).",
    "v": ""
   },
   {
    "k": "f1 formula netflix drive survive marketing brand sponsorship viewership research",
    "s": "The F1 Netflix Effect is a Sem 1 Marketing & Brand Management live project on how Drive to Survive changed Formula 1's brand, US audience and sponsorships.",
    "v": ""
   },
   {
    "k": "openoffice base",
    "s": "OpenOffice Base was used as the database for the F1 Netflix Effect project.",
    "v": ""
   },
   {
    "k": "risk technology it cybersecurity",
    "s": "Shashaank completed the EY Technology Risk job simulation on Forage (Jul 2026), covering typical IT risks and processes.",
    "v": ""
   },
   {
    "k": "strategy strategic planning roadmap",
    "s": "Strategy work includes the Strategic Planning in the AI Age course (HP LIFE) and the Junior AI Business Strategy internship.",
    "v": ""
   },
   {
    "k": "entrepreneur business management",
    "s": "Business management is the focus of his BBA, with an entrepreneurial mindset listed as a skill.",
    "v": ""
   },
   {
    "k": "adaptability punctual punctuality adaptable",
    "s": "Adaptability and punctuality are both listed under soft skills on the CV.",
    "v": ""
   },
   {
    "k": "research internet",
    "s": "Internet research is listed under technical skills.",
    "v": ""
   },
   {
    "k": "linkedin",
    "s": "Two LinkedIn posts are embedded in the 'On LinkedIn' section of this site.",
    "v": ""
   },
   {
    "k": "offer letter letters",
    "s": "Both internship offer letters can be opened from the Internships section.",
    "v": ""
   }
  ]
 },
 "settings": {
  "pageTitle": "Shashaank Kumar Sinha — AI & BBA Student",
  "introEnabled": true,
  "adminSalt": "sk-studio-5b1e9c27",
  "adminIter": 3000,
  "adminHash": "bdd86206c3aaf3a377715dd1ad34bcc603d00f93fc5f9c58abe2c76ca82751c3"
 },
 "badges": [
  {
   "title": "Digital badge",
   "host": "https://www.credly.com",
   "badgeId": "4cac1d08-8af4-4397-8926-5cc3781eabc5",
   "width": "150",
   "height": "270"
  }
 ],
 "intro": {
  "projects": "",
  "internships": "assets/intro/yuvaintern-logo.png",
  "certs": "assets/certs/one-million-prompters.webp",
  "skills": ""
 }
};
